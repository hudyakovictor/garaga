# Base44 — Data Model (Entities)

These are the entities to create in Base44 (Data → New Entity). Field types use
Base44's kinds: `text`, `long text`, `number`, `date`, `datetime`, `select`
(enum), `boolean`, `image/file`, `relation`, `user`. The local prototype's
`data/seed.js` mirrors this exactly so the mapping is 1:1.

---

## 1. Customer
| field | type | notes |
|---|---|---|
| name | text | |
| phone | text | |
| email | text | used for confirmations |
| user | user (relation) | link to Base44 auth user (portal login) |
| created_date | datetime | auto |

## 2. Vehicle
| field | type | notes |
|---|---|---|
| customer | relation → Customer | owner |
| year | number | |
| make | text | |
| model | text | |
| plate | text | |
| vin | text | |
| color | text | |
| mileage | number | |
| photo | image | |

## 3. Service (catalog)
| field | type | notes |
|---|---|---|
| key | text | slug e.g. "brakes" |
| name | text | |
| category | select | Engine, Brakes, Body, Tires, Detailing, Glass, Diagnostics, Other |
| price_min | number | |
| price_max | number | |
| duration | text | "2–3 hours" |
| description | long text | |
| status_tag | select | ok / attention / priority (demo condition) |

## 4. Order (the core entity)
| field | type | notes |
|---|---|---|
| number | text | e.g. NCAR-2024-0587 (auto-generate) |
| customer | relation → Customer | |
| vehicle | relation → Vehicle | |
| service | relation → Service | |
| technician | relation → Technician | |
| status | select | **Pending, Inspection, In Progress, Quality Check, Ready, Completed** |
| stage | number | 1–5 progress step |
| progress | number | 0–100 % |
| estimate_labor | number | |
| estimate_parts | number | |
| estimate_total | number | |
| scheduled_at | datetime | |
| notes | long text | |
| created_date | datetime | auto |

## 5. OrderUpdate (timeline entries + photos)
| field | type | notes |
|---|---|---|
| order | relation → Order | |
| message | text | "Dent removal in progress" |
| photos | file (multiple) | bay photos |
| created_date | datetime | auto |

## 6. Technician
| field | type | notes |
|---|---|---|
| name | text | |
| role | select | Advisor, Body, Paint, Mechanic, Welder |
| avatar | image | |
| active | boolean | |

## 7. Message (live chat)
| field | type | notes |
|---|---|---|
| order | relation → Order | thread key |
| sender | select | customer / staff |
| sender_name | text | |
| body | long text | |
| created_date | datetime | auto |

## 8. Booking (public booking request → becomes Order)
| field | type | notes |
|---|---|---|
| service | relation → Service | |
| date | date | |
| slot | text | "Wed 14:00" |
| name | text | |
| vehicle_desc | text | free text at booking time |
| contact | text | phone/email |
| notes | long text | |
| status | select | New, Confirmed, Converted, Declined |
| created_date | datetime | auto |

## 9. TowRequest (emergency dispatch)
| field | type | notes |
|---|---|---|
| lat | number | |
| lng | number | |
| accuracy | number | meters |
| vehicle_type | select | Car, Truck, SUV, Van |
| problem | text | |
| status | select | Requested, Dispatched, Arrived, Closed |
| ref | text | TOW-XXXXX |
| created_date | datetime | auto |

## 10. Task (CRM kanban)
| field | type | notes |
|---|---|---|
| order | relation → Order | |
| title | text | |
| assignee | relation → Technician | |
| column | select | Pending, In Progress, Completed |
| due | date | |

## 11. Lead (contact form + financing + specials)
| field | type | notes |
|---|---|---|
| name / phone / email | text | |
| kind | select | Contact, Financing, Specials, Review |
| message | long text | |
| meta | long text | JSON extra (loan amount, term, rating…) |
| created_date | datetime | auto |

## Relationships summary
```
Customer 1──* Vehicle
Customer 1──* Order        Vehicle 1──* Order
Service  1──* Order        Technician 1──* Order
Order    1──* OrderUpdate  Order 1──* Message  Order 1──* Task
Booking  ──(convert)──▶ Order
```
