# Pages Map — routes, audience, purpose, automations touched

| Route | Area | Purpose | Key elements | Automations |
|---|---|---|---|---|
| `#/` | Public | Home / hero | hero, trust badges, service preview grid | — |
| `#/services` | Public | Services index | 12 photo tiles → detail | — |
| `#/service/:id` | Public | Service detail (polish later) | split + rich process panel | — |
| `#/about` | Public | Story / team | two-col, badges | — |
| `#/reviews` | Public | Social proof | rating, review cards, write-review | A9 (Review lead) |
| `#/gallery` | Public | Work gallery | image grid | — |
| `#/contact` | Public | Contact + map | info cards, message form | A9 (Contact lead) |
| `#/specials` | Public | Offers | special cards, claim | A9 (Specials lead) |
| `#/financing` | Public | Financing calculator | range slider, monthly calc, apply | A9 (Financing lead) |
| `#/warranty` | Public | Warranty | benefits, 2yr seal | — |
| `#/faq` | Public | FAQ | accordions | — |
| `#/book` | Public | **Booking flow** (4-step modal) | service→date→details→confirm | **A1** |
| (tow button) | Global | **Tow dispatch** (geo flow) | radar, geolocation, dispatch | **A2** |
| `#/portal/order` | Client | **My Service Order** | progress tracker, timeline, estimate, chat link | A3, A4 |
| `#/portal/garage` | Client | My Garage | vehicle list, details, quick actions | — |
| `#/portal/history` | Client | Service History | data table, recommendations | A7 (reminders) |
| `#/portal/chat` | Client | **Live Chat** | thread, send, auto-reply | A5 |
| `#/crm` | Owner | **Dashboard** | 4 stat cards, recent orders table, status donut | — |
| `#/crm/orders` | Owner | Order Management | search, filter, status cycle | A3 (status change) |
| `#/crm/tasks` | Owner | **Tasks (kanban)** | drag between columns | A3 (implied) |
| `#/crm/customers` | Owner | Customers | directory table | — |

## Prototype conveniences (remove/replace on Base44)
- **Role switch** (Public / Client / Owner) in the appbar — on Base44 this is
  real auth + roles, not a toggle.
- **Automation console** (bottom-right ⚡) — a live feed proving which Base44
  automation each action would trigger. Great for the demo video; not shipped
  to end users.
- **"Simulate bay update" / status-cycle buttons** — stand in for staff actions.
