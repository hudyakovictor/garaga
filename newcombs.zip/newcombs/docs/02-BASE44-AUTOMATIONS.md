# Base44 — Automations (challenge core)

The "Give It a Glow" judges score **Automation depth**: does it save time,
improve operations, increase leads, or improve the customer experience?
Below is every automation, its trigger, actions, and how to build it in Base44
(Automations tab → New Automation). Prioritised.

Legend: **Trigger → Action(s)**. "★" = recommended flagship for the submission.

---

## ★ A1 — Booking → confirmation + shop alert  (customer experience + time saved)
**Trigger:** New `Booking` record created (from public booking flow).
**Actions:**
1. Send **email/SMS to customer**: "We got your request for {service} on {date} {slot}. We'll confirm within 2 hours."
2. Send **notification to shop** (email / WhatsApp / Slack): new booking details + one-click "Confirm".
3. (Optional) When staff sets `Booking.status = Confirmed` → **create `Order`** (status Pending) linked to the customer/vehicle and send customer the tracking link `#/portal/order/{number}`.
**Why it scores:** removes phone tag, instant response, auto-creates the work order.
**Base44 build:** Automation on Booking `onCreate` → Email action + Notification action. Second automation on Booking `onUpdate (status=Confirmed)` → Create Record (Order) → Email (tracking link).

## ★ A2 — Tow request → instant dispatch  (revenue + safety, flagship demo)
**Trigger:** New `TowRequest` created (geolocation captured in browser).
**Actions:**
1. **SMS/WhatsApp to on-call driver** with a Google Maps deep link `https://maps.google.com/?q={lat},{lng}`, vehicle type, problem, `ref`.
2. **Email/notification to shop** dispatch board.
3. Reply to customer with ETA + `ref` (already shown in UI; automation logs it).
**Why it scores:** turns a panic moment into a 1-tap dispatch with exact GPS — very demoable in the Loom.
**Base44 build:** Automation on TowRequest `onCreate` → SMS/Notification action using record fields in the message template.

## A3 — Order status change → customer update  (customer experience)
**Trigger:** `Order.status` changes.
**Actions:** Email/SMS customer: "Your {vehicle} is now **{status}** — {progress}% done. Track it: {link}." Optionally attach latest `OrderUpdate.photos`.
**Base44 build:** Automation on Order `onUpdate` with condition "status changed" → Email action.

## A4 — New OrderUpdate w/ photo → notify customer  (transparency)
**Trigger:** New `OrderUpdate` created.
**Action:** Push/email the customer the message + photos ("New photo from the bay").
**Base44 build:** Automation on OrderUpdate `onCreate` → Email/Notification.

## A5 — New chat Message (staff → customer)  (engagement)
**Trigger:** New `Message` where `sender = staff`.
**Action:** Notify the customer (email/push) that they have a reply; deep link to `#/portal/chat/{order}`.
**Base44 build:** Automation on Message `onCreate` + condition sender=staff.

## A6 — Ready for pickup  (throughput)
**Trigger:** `Order.status = Ready`.
**Action:** SMS "Your truck is ready! Shop hours Mon–Fri 8–6." + request a review link (feeds A8).
**Base44 build:** Order onUpdate condition status=Ready → SMS.

## A7 — Service reminders (recurring)  (retention / repeat revenue)
**Trigger:** Scheduled (daily) — find Vehicles whose `mileage`/last service crosses interval, or Orders completed N months ago.
**Action:** Email "Time for your oil change / inspection."
**Base44 build:** Scheduled Automation (cron) → Query records → Email each.

## A8 — Review request → Lead  (reputation)
**Trigger:** 1 day after `Order.status = Completed`.
**Action:** Email asking for a Google review; capture response as `Lead(kind=Review)`.
**Base44 build:** Scheduled/delayed automation after completion.

## A9 — Financing / Contact / Specials form → Lead + alert  (lead gen)
**Trigger:** New `Lead` created (from Contact form, Financing calculator "Apply", Specials "Claim").
**Action:** Email the shop with the lead + auto-reply to the customer.
**Base44 build:** Automation on Lead onCreate → 2 Email actions.

## A11 — Estimate approved → authorize work  (throughput + upsell)
**Trigger:** `Order.approval = approved` (customer taps Approve in the portal).
**Actions:** set `Order.status = In Progress`; notify the assigned technician
("Work authorized on {order} — {total}"); log timestamp for cycle-time metrics.
**Base44 build:** Order onUpdate condition approval=approved → Update Record +
Notification.

## A12 — Estimate declined → advisor follow-up  (recovery)
**Trigger:** `Order.approval = declined`.
**Action:** create a task / notify the service advisor to call the customer and
offer alternatives.
**Base44 build:** Order onUpdate condition approval=declined → Create Task +
Notification.

## ★ A10 — AI Superagent (bonus points)
A Base44 **AI Superagent** trained on shop FAQ + services + hours that:
- answers customer questions (hours, warranty, "do you tow?"),
- can **create a Booking** or **TowRequest** from chat,
- hands off to a human (creates a `Message`/notification) when unsure.
**Why it scores:** the challenge explicitly lists "AI Superagent for bookings, FAQs, or customer support" as a bonus.

---

## Suggested submission automation set (what to demo in the Loom)
1. **A1 Booking → confirm** (before/after: their Wix form vs this)
2. **A2 Tow dispatch** (wow moment, GPS)
3. **A3 status → customer update** (transparency)
4. **A10 AI Superagent** (bonus)

Each maps to a visible UI action already built in the prototype, so the demo
flows: click in UI → record created → automation fires → message/notification.
