# Rebuilding this on Base44 — step by step

Goal: recreate this prototype as a live Base44 app for the "Give It a Glow"
challenge, with working automations, then record the before/after video.

## 0. Setup
1. Create a free account at base44.com, start a new app "Newcomb's Auto Repair".
2. Redeem challenge credits: Workspace → Settings → Credit Usage → redeem code.

## 1. Data (entities)
Create the 11 entities from `01-BASE44-ENTITIES.md` (Data → New Entity). Add
the fields with the listed types and relations. Import `data/seed.js` values as
starter records (or add a few by hand for the demo).

## 2. Pages
Recreate the routes from `03-PAGES-MAP.md`. In Base44 you can prompt the
builder with each page's purpose + elements. Suggested prompts:
- "Public home page: dark industrial garage hero, headline HONEST WORK / REAL
  PEOPLE / SOLID RESULTS, amber CTA 'Book appointment', service grid pulling
  from the Service entity."
- "Client portal 'My Service Order': read the Order for the logged-in customer,
  show a 5-step progress tracker (Received→Inspection→In Progress→Quality
  Check→Ready), a timeline of OrderUpdate records with photos, and an estimate."
- "Owner CRM dashboard: stat cards (total/in-progress/completed/revenue),
  recent Orders table, and a donut of Orders by status."
- Keep the visual language: dark `#0a0b0c`, tactical amber `#ff8a1e`, Oswald +
  Inter + JetBrains Mono. Reuse the CSS tokens in `css/tokens.css`.

## 3. Roles / auth
Enable auth. Two roles: **customer** (sees only their Orders/Vehicles/Chat) and
**staff/owner** (CRM). Replace the prototype's role-switch with real login.

## 4. Automations (the scored part — see 02-BASE44-AUTOMATIONS.md)
Build at least these for the submission:
1. **A1 Booking → confirmation + shop alert** (Booking onCreate → Email x2).
   Add a second automation: Booking status=Confirmed → Create Order → Email
   tracking link.
2. **A2 Tow → dispatch** (TowRequest onCreate → SMS/WhatsApp to driver with
   `https://maps.google.com/?q={lat},{lng}` + notify shop).
3. **A3 Order status → customer update** (Order onUpdate → Email/SMS).
4. **A10 AI Superagent** (bonus): train on services + hours + FAQ; allow it to
   create Booking / TowRequest and hand off to staff.

Each maps to a button already in this prototype, so the demo flows naturally.

## 5. The submission package (all four required)
- **Product:** the live Base44 URL (published, mobile-responsive).
- **Automation:** at least A1 (A2 + A10 for bonus).
- **Story:** Loom — show the current Wix site
  (newcombsautorepair.wixsite.com/auto), then this app, then trigger an
  automation live (booking confirmation / tow dispatch).
- **Post:** LinkedIn/X with before → after → automation, tag **#GiveItAGlow**
  and **@Base44**.

## 6. Bonus points checklist
- [ ] Business actively using it (reach out to Newcomb's — see cold-outreach note)
- [ ] Before/after fully documented
- [ ] AI Superagent implemented (A10)
- [ ] Automation demonstrably saves time (A1 replaces phone tag; A2 replaces a
      panicked call with 1-tap GPS dispatch)
