# Newcomb's Auto Repair — Project Architecture

> Prototype-first. One connected app, single design system. We wire all the
> important pages together, then polish page-by-page. Built to be re-created on
> **base44.com** for the "Give It a Glow" challenge.

## Folder layout
```
newcombs/
  index.html            # app shell + client-side router (hash routes)
  css/
    tokens.css          # design tokens (color, type, spacing, motion)
    base.css            # resets + primitives + utility classes
    app.css             # shell: nav, sidebars, layout regions
    components.css      # reusable components (cards, tables, panels, chat…)
  js/
    router.js           # hash router + page mounting
    store.js            # in-memory data store (stands in for Base44 entities)
    ui.js               # shared UI helpers (icons, toast, modal, format)
    pages/*.js          # one module per page (renders into #view)
    flows/*.js          # booking flow, tow-dispatch flow, chat
  components/           # (reserved) extracted HTML partials if needed
  data/
    seed.js             # seed records: services, orders, vehicles, customers…
  assets/               # images (garage photos, logo)
  docs/
    00-ARCHITECTURE.md  # this file
    01-BASE44-ENTITIES.md   # data model → Base44 entities & fields
    02-BASE44-AUTOMATIONS.md# every automation, trigger, and how to build it
    03-PAGES-MAP.md         # every route, who sees it, what it does
    04-BUILD-ON-BASE44.md   # step-by-step rebuild guide
```

## Roles / areas
- **Public** — marketing + services + booking + tow (no login).
- **Client portal** — logged-in customer: track order, garage, history, chat.
- **Owner CRM** — shop staff: dashboard, orders, tasks, customers, calendar.

## Router model
Hash-based routes so it runs anywhere and maps cleanly to Base44 pages later.
```
#/                     Home / hub
#/services             Services index (grid → detail)
#/service/:id          Service detail (typical page, polish later)
#/book                 Booking flow (modal-style full page)
#/tow                  Tow dispatch flow
#/about #/reviews #/gallery #/contact #/specials #/financing #/warranty #/faq
#/portal               Client home (redirect → order)
#/portal/order/:id     My Service Order (live tracker)
#/portal/garage        My Garage
#/portal/history       Service History
#/portal/chat/:id      Live Chat
#/crm                  CRM Dashboard
#/crm/orders           Order Management
#/crm/tasks            Tasks (kanban)
#/crm/order/:id        Order detail (staff)
```

## Design system (single source of truth)
- Palette: oily black `#0a0b0c`, steel greys, tactical amber `#ff8a1e`,
  status green/amber/red, faded yellow labels.
- Type: Oswald (display, condensed), Inter (body), JetBrains Mono (data/HUD).
- Everything dark, industrial, HUD-flavored (NFS-Underground-grown-up).

## Build order (most elements → least)
1. Shell + router + store + design tokens
2. CRM Dashboard (most varied components: metrics, donut, table, list)
3. CRM Order Management (table, filters, status)
4. CRM Tasks (kanban, drag)
5. Client My Service Order (timeline tracker, updates, estimate)
6. Client My Garage + Service History
7. Live Chat
8. Booking flow + Tow dispatch (automation triggers)
9. Public: Home, About, Reviews, Gallery, Contact, Specials, Financing, Warranty, FAQ
10. Individual service detail pages (typical — last)
```
