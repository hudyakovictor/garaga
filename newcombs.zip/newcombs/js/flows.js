/* ============================================================
   FLOWS — booking (4-step) + tow dispatch (geolocation)
   Each creates a Store record → fires the mapped Base44 automation.
   ============================================================ */
window.Flows = (() => {
  const S = () => window.Store.db;

  /* -------- BOOKING (Service → Vehicle → Date/Time → Confirm) -------- */
  function booking(preselect){
    let step=0, st={service:preselect||'',vehicleId:'',vehicle:'',date:'',slot:'',name:'',contact:'',notes:''};
    const slots=['Mon 09:00','Tue 11:30','Wed 14:00','Thu 10:00','Fri 15:00','Sat 09:30'];
    // demo "my garage" — in Base44 this is the logged-in customer's Vehicles
    const garage=S().vehicles.filter(v=>v.customer==='c1');
    openModal(shell(),'');
    render();
    function shell(){return `<div class="modal__head"><div><h3>Book a bay</h3><p>Confirmed in ~2 hours · ASE certified</p></div><button class="modal__close" data-close>${svg('plus',15).replace('M12 5v14M5 12h14','M6 6l12 12M18 6L6 18')}</button></div>
      <div class="stepper" style="padding:16px 22px 4px">${['SERVICE','VEHICLE','DATE & TIME','CONFIRM'].map((l,i)=>`<div class="bkstep" data-pip="${i}"><span class="bkstep__n">${i+1}</span><span class="bkstep__l">${l}</span></div>`).join('')}</div>
      <div class="modal__body" id="bkBody"></div><div class="modal__foot" id="bkFoot"></div>`;}
    function pips(){$$('[data-pip]').forEach((p,i)=>{p.classList.toggle('done',i<step);p.classList.toggle('active',i===step);});}
    function render(){pips();[svc,vehicle,time,rev][step]();}

    function svc(){$('#bkBody').innerHTML=`<div class="tag" style="margin-bottom:12px">STEP 1/4 · SELECT SERVICE</div><div class="opt-grid">${S().services.map(x=>`<button class="opt-card ${st.service===x.key?'sel':''}" data-svc="${x.key}"><span class="ic">${svg('wrench',18)}</span><span><b>${x.name}</b><span>${window.fmtMoney(x.price_min)}–${window.fmtMoney(x.price_max)}</span></span></button>`).join('')}</div>`;
      $$('[data-svc]').forEach(b=>b.onclick=()=>{st.service=b.dataset.svc;$$('#bkBody .opt-card').forEach(c=>c.classList.remove('sel'));b.classList.add('sel');});
      foot(`<button class="btn btn--ghost" data-close>Cancel</button><button class="btn btn--amber" id="nx">Continue ${svg('arrow',15)}</button>`);
      $('#nx').onclick=()=>{if(!st.service)return toast('Pick a service');step=1;render();};}

    function vehicle(){$('#bkBody').innerHTML=`<div class="tag" style="margin-bottom:12px">STEP 2/4 · YOUR VEHICLE</div>
      <div class="opt-grid" style="grid-template-columns:1fr">
        ${garage.map(v=>`<button class="opt-card ${st.vehicleId===v.id?'sel':''}" data-veh="${v.id}"><span class="ic">${svg('car',18)}</span><span><b>${v.year} ${v.make} ${v.model}</b><span>${v.color} · ${v.plate} · ${(v.mileage||0).toLocaleString()} mi</span></span></button>`).join('')}
        <button class="opt-card ${st.vehicleId==='new'?'sel':''}" data-veh="new"><span class="ic">${svg('plus',18)}</span><span><b>Add a different vehicle</b><span>Enter year / make / model</span></span></button>
      </div>
      <div class="field ${st.vehicleId==='new'?'':'hide'}" id="newVehWrap" style="margin-top:12px"><label>Vehicle (year / make / model)</label><input id="newVeh" value="${st.vehicle}" placeholder="'19 RAM 1500"></div>`;
      $$('[data-veh]').forEach(b=>b.onclick=()=>{st.vehicleId=b.dataset.veh;$$('#bkBody .opt-card').forEach(c=>c.classList.remove('sel'));b.classList.add('sel');$('#newVehWrap').classList.toggle('hide',st.vehicleId!=='new');if(st.vehicleId!=='new'){const v=Store.veh(st.vehicleId);st.vehicle=`${v.year} ${v.make} ${v.model}`;}});
      foot(`<button class="btn btn--ghost" id="bk">Back</button><button class="btn btn--amber" id="nx">Continue ${svg('arrow',15)}</button>`);
      $('#bk').onclick=()=>{step=0;render();};
      $('#nx').onclick=()=>{if(!st.vehicleId)return toast('Pick a vehicle');if(st.vehicleId==='new'){st.vehicle=$('#newVeh').value.trim();if(!st.vehicle)return toast('Enter your vehicle');}step=2;render();};}

    function time(){const min=new Date().toISOString().split('T')[0];$('#bkBody').innerHTML=`<div class="tag" style="margin-bottom:12px">STEP 3/4 · DATE & TIME</div><div class="field"><label>Date</label><input type="date" id="bd" min="${min}" value="${st.date||min}"></div><div class="field"><label>Slot</label><div class="row gap2" style="flex-wrap:wrap">${slots.map(s=>`<button class="chip ${st.slot===s?'sel':''}" data-slot="${s}">${s}</button>`).join('')}</div></div>
      <div class="field-row"><div class="field" id="fn"><label>Full name</label><input id="bn" value="${st.name}" placeholder="Jason Newcomb"><span class="msg">Required</span></div><div class="field" id="fc"><label>Phone or email</label><input id="bc" value="${st.contact}" placeholder="540-555-0000"><span class="msg">Required</span></div></div>
      <div class="field"><label>Notes (optional)</label><textarea id="bno" rows="2">${st.notes}</textarea></div>`;
      $$('[data-slot]').forEach(b=>b.onclick=()=>{st.slot=b.dataset.slot;$$('#bkBody .chip').forEach(c=>c.classList.remove('sel'));b.classList.add('sel');});
      foot(`<button class="btn btn--ghost" id="bk">Back</button><button class="btn btn--amber" id="nx">Review ${svg('arrow',15)}</button>`);
      const save=()=>{st.date=$('#bd').value;st.name=$('#bn').value;st.contact=$('#bc').value;st.notes=$('#bno').value;};
      $('#bk').onclick=()=>{save();step=1;render();};
      $('#nx').onclick=()=>{save();if(!st.slot)return toast('Pick a slot');let ok=1;if(!st.name.trim()){$('#fn').classList.add('err');ok=0;}else $('#fn').classList.remove('err');if(!st.contact.trim()){$('#fc').classList.add('err');ok=0;}else $('#fc').classList.remove('err');if(ok){step=3;render();}};}

    function rev(){const x=Store.svc(st.service);$('#bkBody').innerHTML=`<div class="tag" style="margin-bottom:12px">STEP 4/4 · CONFIRM</div><div class="card" style="padding:16px">${[['Service',x.name+' · '+window.fmtMoney(x.price_min)+'–'+window.fmtMoney(x.price_max)],['Vehicle',st.vehicle||'—'],['When',st.date+' · '+st.slot],['Name',st.name],['Contact',st.contact]].map(r=>`<div class="between mono" style="padding:7px 0;border-bottom:1px solid var(--line)"><span class="faint">${r[0]}</span><span>${r[1]}</span></div>`).join('')}</div><p class="mono faint" style="margin-top:12px;line-height:1.6">⚡ Confirming fires <b class="amber">A1 · Booking automation</b> (customer confirmation + shop alert → auto-create Order).</p>`;
      foot(`<button class="btn btn--ghost" id="bk">Back</button><button class="btn btn--amber" id="cf">Confirm ${svg('check',15)}</button>`);
      $('#bk').onclick=()=>{step=2;render();};$('#cf').onclick=()=>{Store.createBooking({service:st.service,date:st.date,slot:st.slot,name:st.name,vehicle_desc:st.vehicle,contact:st.contact,notes:st.notes});done(x);};}

    function done(x){const ref='NCB-'+Math.random().toString(36).slice(2,7).toUpperCase();$('#bkBody').innerHTML=`<div style="text-align:center;padding:20px 0"><div style="width:60px;height:60px;border-radius:50%;border:1px solid var(--amber);color:var(--amber);display:grid;place-items:center;margin:0 auto 16px">${svg('check',28)}</div><h3>Bay reserved</h3><p class="dim" style="margin-top:8px;max-width:36ch;margin-inline:auto">We'll confirm your <b class="amber">${x.name}</b> on <b>${st.vehicle}</b> for <b>${st.date} ${st.slot}</b> within ~2 hours.</p><div class="mono amber" style="margin-top:12px">REF · ${ref}</div></div>`;
      foot(`<span class="mono faint">Sent to ${st.contact}</span><button class="btn btn--amber" data-close>Done</button>`);}
    function foot(h){$('#bkFoot').innerHTML=h;$$('[data-close]',$('#modal')).forEach(b=>b.onclick=closeModal);}
  }

  /* -------- TOW DISPATCH -------- */
  function tow(){
    let coords=null, veh='Truck', problem='';
    openModal(shell(),'tow-modal'); step0();
    function shell(){return `<div class="modal__head"><div><h3>Call a tow truck</h3><p>We come to you · sharing live GPS</p></div><button class="modal__close" data-close>${svg('plus',15).replace('M12 5v14M5 12h14','M6 6l12 12M18 6L6 18')}</button></div><div class="modal__body" id="towBody"></div><div class="modal__foot" id="towFoot"></div>`;}
    function radar(){return `<div style="position:relative;height:190px;border:1px solid var(--line);border-radius:var(--r2);overflow:hidden;background:radial-gradient(circle at 50% 55%,#141a20,#0a0b0c);margin-bottom:14px">
      <div style="position:absolute;inset:0;background-image:linear-gradient(rgba(84,207,139,.08) 1px,transparent 1px),linear-gradient(90deg,rgba(84,207,139,.08) 1px,transparent 1px);background-size:26px 26px"></div>
      <div style="position:absolute;left:50%;top:55%;width:120px;height:2px;background:linear-gradient(90deg,var(--ok),transparent);transform-origin:left;animation:sweep 3s linear infinite"></div>
      <div style="position:absolute;left:26%;top:32%;width:10px;height:10px;border-radius:50%;background:var(--ok);box-shadow:0 0 10px var(--ok)"></div>
      <div class="dot amber pulse" style="position:absolute;left:50%;top:55%;width:12px;height:12px;transform:translate(-50%,-50%)"></div>
      <div class="mono" style="position:absolute;bottom:10px;left:12px;font-size:10px;color:var(--dim)">SHOP <b class="ok">●</b> · YOU <b class="amber">●</b></div></div>`;}
    function step0(){$('#towBody').innerHTML=`${radar()}<div class="mono" id="gs" style="font-size:11px;color:var(--dim);margin-bottom:12px"><span class="dot warn"></span> Location not shared yet</div><p class="lede" style="font-size:13px">Share your location and we'll dispatch the nearest truck straight to you.</p>`;
      foot(`<button class="btn btn--ghost" data-close>Cancel</button><button class="btn btn--amber" id="geo">${svg('pin',16)} Share my location</button>`);
      $('#geo').onclick=getGeo;}
    function getGeo(){$('#gs').innerHTML='<span class="dot amber pulse"></span> Locating…';
      const ok=p=>{coords={lat:+p.coords.latitude.toFixed(5),lng:+p.coords.longitude.toFixed(5),accuracy:Math.round(p.coords.accuracy)};step1();};
      const fail=()=>{coords={lat:37.06,lng:-78.60,accuracy:0,approx:1};toast('Using approx area');step1();};
      if(navigator.geolocation)navigator.geolocation.getCurrentPosition(ok,fail,{enableHighAccuracy:true,timeout:8000});else fail();}
    function step1(){const vehs=['Car','Truck','SUV','Van'];$('#towBody').innerHTML=`${radar()}<div class="mono" style="font-size:11px;color:var(--dim);margin-bottom:12px"><span class="dot ok"></span> Location locked ${coords.approx?'(approx)':'· ±'+coords.accuracy+'m'} · ${coords.lat}, ${coords.lng}</div>
      <div class="field"><label>Vehicle type</label><div class="row gap2" style="flex-wrap:wrap">${vehs.map(v=>`<button class="chip ${v===veh?'sel':''}" data-v="${v}">${v}</button>`).join('')}</div></div>
      <div class="field"><label>What happened?</label><textarea id="tp" rows="2" placeholder="Won't start, flat, accident…">${problem}</textarea></div>
      <div class="row gap2"><div class="card" style="flex:1;padding:12px;text-align:center"><b class="disp amber" style="font-size:24px">18</b><div class="tag">MIN ETA</div></div><div class="card" style="flex:1;padding:12px;text-align:center"><b class="disp" style="font-size:24px">24/7</b><div class="tag">DISPATCH</div></div></div>`;
      $$('[data-v]').forEach(b=>b.onclick=()=>{veh=b.dataset.v;$$('#towBody .chip').forEach(c=>c.classList.remove('sel'));b.classList.add('sel');});
      foot(`<button class="btn btn--ghost" id="bk">Back</button><button class="btn btn--amber" id="go">Dispatch truck ${svg('check',15)}</button>`);
      $('#bk').onclick=step0;$('#go').onclick=()=>{problem=$('#tp').value;dispatch();};}
    function dispatch(){const rec=Store.createTow({lat:coords.lat,lng:coords.lng,accuracy:coords.accuracy,vehicle_type:veh,problem});
      const g=`https://maps.google.com/?q=${coords.lat},${coords.lng}`;const sms=encodeURIComponent(`TOW ${rec.ref} — ${veh}. ${problem||'assistance'}. ${coords.lat},${coords.lng} ${g}`);
      $('#towBody').innerHTML=`<div style="text-align:center;padding:16px 0"><div style="width:60px;height:60px;border-radius:50%;border:1px solid var(--amber);color:var(--amber);display:grid;place-items:center;margin:0 auto 16px">${svg('tow',28)}</div><h3>Truck dispatched</h3><p class="dim" style="margin-top:8px;max-width:34ch;margin-inline:auto">A driver is on the way to <b class="amber">${coords.lat}, ${coords.lng}</b>.</p><div class="row gap2" style="margin-top:18px"><div class="card" style="flex:1;padding:12px;text-align:center"><b class="disp amber" style="font-size:24px">18</b><div class="tag">MIN ETA</div></div><div class="card" style="flex:1;padding:12px;text-align:center"><b class="disp" style="font-size:20px">${rec.ref.slice(-3)}</b><div class="tag">UNIT</div></div></div><div class="mono amber" style="margin-top:14px">REF · ${rec.ref}</div></div>`;
      foot(`<a class="btn btn--ghost" href="${g}" target="_blank" rel="noopener">Open map</a><a class="btn btn--amber" href="sms:${S().shop.phone}?&body=${sms}">Text the shop</a>`);}
    function foot(h){$('#towFoot').innerHTML=h;$$('[data-close]',$('#modal')).forEach(b=>b.onclick=closeModal);}
  }

  return { booking, tow };
})();
