/* ============================================================
   PAGES — every route renders here (prototype). Polish later.
   ============================================================ */
window.Pages = (() => {
  const S = () => window.Store.db;
  const A = 'assets/'; // legacy; use asset()

  /* ---------------- PUBLIC ---------------- */
  function home(){
    const s = S().shop;
    return `
    <section class="hero">
      <div class="hero__bg"><img src="${asset('hero-overview.jpg')}" alt="Pickup truck in Newcomb's garage"></div>
      <div class="hero__scrim"></div>
      <div class="hero__in wrap">
        <div class="hero__copy">
          <div class="eyebrow">Drakes Branch, VA</div>
          <h1 class="hero__title">Honest work.<br>Real people.<br><span class="amber">Solid results.</span></h1>
          <p class="hero__sub">Full-service auto repair and maintenance for everything that keeps you moving.</p>
          <div class="hero__cta">
            <a href="#/book" class="btn btn--amber btn--lg">Book appointment ${svg('arrow',16)}</a>
            <a href="#/services" class="btn btn--ghost btn--lg">View services</a>
          </div>
        </div>
      </div>
      <div class="hero__trust wrap">
        <div class="trust__item"><span class="trust__ic">${svg('check',18)}</span><div><b>ASE</b><span>Certified Technicians</span></div></div>
        <div class="trust__item"><span class="trust__ic">${svg('settings',18)}</span><div><b>NAPA</b><span>2-Year / 24k Warranty</span></div></div>
        <div class="trust__item"><span class="trust__ic amber">${svg('star',18)}</span><div><b>5-Star</b><span>Customer Ratings</span></div></div>
        <div class="trust__item trust__hours"><span class="trust__ic">${svg('history',18)}</span><div><b>Hours</b><span>${s.hours}</span></div></div>
      </div>
    </section>
    <section class="wrap section-block">
      <div class="sec-head"><div><div class="eyebrow">What we do</div><h2 style="margin-top:14px">Our <span class="thin">Services</span></h2></div><a href="#/services" class="btn btn--ghost btn--sm">All services ${svg('arrow',14)}</a></div>
      <div class="svc-index">${S().services.slice(0,9).map((sv,i)=>svcTile(sv,i)).join('')}</div>
    </section>`;
  }
  // detailed, chromed service icons (multi-element SVG, 40x40 viewBox)
  // ---- detailed badge-style service icons (round emblem, chrome + amber) ----
  const SVC_SCENE={
    diagnostics:`<rect x="20" y="30" width="60" height="40" rx="5" stroke="url(#chrome)"/><path d="M20 58h16l5-11 7 20 5-11 4 2h18" stroke="var(--amber)" stroke-width="3"/><rect x="26" y="36" width="48" height="4" rx="2" class="g2"/><circle cx="70" cy="59" r="3" fill="var(--amber)" stroke="none"/>`,
    engine:`<path d="M28 44h9l6-6h12v8h9l7 7v11h-6v7H37v-7H28z" stroke="url(#chrome)"/><path d="M55 38v-7h-11" stroke="url(#chrome)"/><path d="M71 53h9" stroke="url(#chrome)"/><path d="M34 44v-7" stroke="url(#chrome)"/><rect x="42" y="47" width="16" height="9" rx="2" fill="var(--amber)" opacity=".9" stroke="none"/>`,
    brakes:`<circle cx="50" cy="50" r="27" stroke="url(#chrome)"/><circle cx="50" cy="50" r="12" stroke="url(#chrome)"/>${Array.from({length:16}).map((_,k)=>{const a=k/16*Math.PI*2;return `<line x1="${(50+Math.cos(a)*15).toFixed(1)}" y1="${(50+Math.sin(a)*15).toFixed(1)}" x2="${(50+Math.cos(a)*25).toFixed(1)}" y2="${(50+Math.sin(a)*25).toFixed(1)}" class="g2"/>`}).join('')}<path d="M63 62a17 17 0 0 0 4-20l-6 3a10 10 0 0 1-2 12z" fill="var(--amber)" stroke="none"/>`,
    suspension:`<path d="M35 25v22a15 15 0 0 0 30 0V25" stroke="url(#chrome)"/><path d="M27 25h16M57 25h16" stroke="url(#chrome)"/><path d="M50 62v13" stroke="var(--amber)" stroke-width="3"/>${Array.from({length:5}).map((_,k)=>`<path d="M40 ${30+k*6}h20" class="g2"/>`).join('')}<circle cx="50" cy="77" r="3.4" fill="var(--amber)" stroke="none"/>`,
    oil:`<path d="M28 30h30l9 11v9a8 8 0 0 1-8 8H36l-8-8z" stroke="url(#chrome)"/><path d="M28 50v18a6 6 0 0 0 6 6h18" stroke="url(#chrome)"/><path d="M67 42v11" stroke="url(#chrome)"/><path d="M67 53c0 5 5 8 5 12a5 5 0 1 1-10 0c0-4 5-7 5-12z" fill="var(--amber)" stroke="none"/>`,
    tires:`<circle cx="50" cy="50" r="27" stroke="url(#chrome)"/><circle cx="50" cy="50" r="13" stroke="url(#chrome)"/>${Array.from({length:10}).map((_,k)=>{const a=k/10*Math.PI*2;return `<line x1="${(50+Math.cos(a)*13).toFixed(1)}" y1="${(50+Math.sin(a)*13).toFixed(1)}" x2="${(50+Math.cos(a)*27).toFixed(1)}" y2="${(50+Math.sin(a)*27).toFixed(1)}" stroke="url(#chrome)" stroke-width="3"/>`}).join('')}<circle cx="50" cy="50" r="5" fill="var(--amber)" stroke="none"/>`,
    dent:`<path d="M22 62l9-25a5 5 0 0 1 4.7-3.3h28.6a5 5 0 0 1 4.7 3.3l9 25" stroke="url(#chrome)"/><path d="M22 62h56v7H22z" stroke="url(#chrome)"/><circle cx="34" cy="65" r="4" stroke="url(#chrome)"/><circle cx="66" cy="65" r="4" stroke="url(#chrome)"/><path d="M42 40q8 9 16 0" stroke="var(--amber)" stroke-width="3"/>`,
    paint:`<path d="M24 76l24-24" stroke="url(#chrome)"/><path d="M48 52l22-22a6 6 0 0 0-8.5-8.5l-22 22" stroke="url(#chrome)"/><path d="M55 24l9 9" stroke="url(#chrome)"/><path d="M24 76l-3 7 7-3z" fill="var(--amber)" stroke="none"/><path d="M68 55c5 0 8 3 8 8s-3 8-8 8" class="g2"/>`,
    glass:`<path d="M20 34l7-12h46l7 12v9a30 14 0 0 1-60 0z" stroke="url(#chrome)"/><path d="M50 22v33" stroke="url(#chrome)"/><path d="M30 42l9 9M70 38l-11 13" class="g2"/><path d="M50 34l5 5-5 5-5-5z" fill="var(--amber)" stroke="none"/>`,
    detailing:`<path d="M22 46l14-22h28l14 22" stroke="url(#chrome)"/><path d="M22 46v17a5 5 0 0 0 5 5h5M78 46v17a5 5 0 0 1-5 5h-5" stroke="url(#chrome)"/><path d="M32 68h36" stroke="url(#chrome)"/><rect x="34" y="32" width="32" height="10" rx="2" class="g2"/><path d="M74 22l4-7 4 7-4 3z" fill="var(--amber)" stroke="none"/>`,
    body:`<path d="M16 54l8-21a6 6 0 0 1 5.6-3.9h40.8a6 6 0 0 1 5.6 3.9l8 21" stroke="url(#chrome)"/><path d="M16 54h68v11H16z" stroke="url(#chrome)"/><circle cx="32" cy="66" r="5" stroke="url(#chrome)"/><circle cx="68" cy="66" r="5" stroke="url(#chrome)"/><path d="M60 18l9 9-9 9-9-9z" fill="var(--amber)" stroke="none"/>`,
  };
  function svcBadge(key){return `<svg class="svc-badge" viewBox="0 0 100 100" fill="none" stroke="url(#chrome)" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
    <circle class="svc-badge__ring" cx="50" cy="50" r="46" stroke="url(#chrome)" stroke-width="1.5"/>
    <circle class="svc-badge__ring2" cx="50" cy="50" r="41" class="g2" stroke-width="1"/>
    ${Array.from({length:36}).map((_,k)=>{const a=k/36*Math.PI*2;return `<line x1="${(50+Math.cos(a)*43).toFixed(1)}" y1="${(50+Math.sin(a)*43).toFixed(1)}" x2="${(50+Math.cos(a)*45).toFixed(1)}" y2="${(50+Math.sin(a)*45).toFixed(1)}" class="g3"/>`}).join('')}
    <g class="svc-badge__scene">${SVC_SCENE[key]||SVC_SCENE.brakes}</g>
  </svg>`;}
  const SVC_NAME={
    diagnostics:'Vehicle Diagnostics', engine:'Engine Repair', brakes:'Brake Service',
    suspension:'Suspension & Steering', oil:'Oil & Fluids', tires:'Tires & Wheels',
    dent:'Dent Repair', paint:'Paint Correction', glass:'Glass & Windshield',
    detailing:'Interior Detailing', body:'Body & Collision',
  };
  const SVC_BLURB={
    diagnostics:'Full computer scan and an honest, priced report.',
    engine:'Timing, gaskets and full rebuilds — done right.',
    brakes:'Pads, rotors and fluid with a free safety check.',
    suspension:'Shocks, joints and alignment for a straight ride.',
    oil:'Synthetic-blend change plus a multi-point check.',
    tires:'Sell, mount and computer-balance — most same day.',
    dent:'Paintless dent removal that leaves no trace.',
    paint:'Machine correction and flawless color match.',
    glass:'Chip and crack repair — insurance often covers it.',
    detailing:'Deep interior clean and headlight restoration.',
    body:'Collision repair &amp; refinish — we bill insurance.',
  };
  function svcTile(sv,i){
    return `<a class="svc-tile" href="#/service?id=${sv.key}">
      <span class="svc-tile__num">${String(i+1).padStart(2,'0')}</span>
      <span class="svc-tile__ic"><img src="${asset('ic-'+sv.key+'.jpg')}" alt="" loading="lazy"></span>
      <h3 class="svc-tile__name">${SVC_NAME[sv.key]||sv.name}</h3>
      <p class="svc-tile__desc">${SVC_BLURB[sv.key]||''}</p>
      <span class="svc-tile__sweep"></span>
      <span class="svc-tile__edge"></span>
    </a>`;
  }

  // per-service marketing detail (headline, checklist, process, before/after)
  const SVC_DETAIL = {
    diagnostics:{head:['WE FIND THE PROBLEM.','YOU SAVE THE GUESS.'],img:'svc-diagnostics',checklist:['Check engine light','Electrical issues','Sensor testing','Performance issues','Computer scan'],steps:['Connect scanner','Read fault codes','Live data test','Written report'],ba:null,note:'Diagnostic fee $60 · applied to any repair you approve.'},
    engine:{head:['BUILT TO LAST.','MADE TO RUN.'],img:'svc-engine',checklist:['Timing belt / chain','Head gaskets','Valve covers','Thermostats','Engine replacement'],steps:['Inspect & test','Compression check','Replace parts','Road test'],ba:null,note:'Most vehicles need a timing belt around 100,000 miles.'},
    brakes:{head:['SAFE STOPS.','EVERY TIME.'],img:'svc-brakes',checklist:['Brake inspection','Pad replacement','Rotor service','Brake fluid','ABS diagnostics'],steps:['Inspect system','Measurements','Replace parts','System check','Road test'],ba:['svc-brakes','svc-brakes'],note:'Free brake inspection with any brake service.'},
    suspension:{head:['WHERE PERFORMANCE','MEETS CONTROL.'],img:'svc-suspension',checklist:['Shocks & struts','Control arms','Ball joints','Tie rods','Alignments'],steps:['Lift & inspect','Measure ride height','Replace worn parts','4-wheel alignment'],ba:null,note:'Includes a printed alignment report.'},
    oil:{head:['FRESH FLUIDS.','SMOOTH MILES.'],img:'svc-oil',checklist:['Synthetic blend','Oil filter','Fluid top-off','Multi-point check'],steps:['Drain & filter','Refill synthetic','Top off fluids','Multi-point check'],ba:null,note:'Improve gas mileage with regular changes.'},
    tires:{head:['GRIP THE ROAD.','ROLL WITH CONFIDENCE.'],img:'svc-tires',checklist:['New tires','Mount & balance','Plug repairs','TPMS reset'],steps:['Select tires','Mount','Computer balance','Torque & test'],ba:['svc-tires','svc-tires'],note:'Most tires in-stock within an hour. Mount $10, plugs $5.'},
    dent:{head:['WE BRING IT BACK','TO FACTORY SMOOTH.'],img:'svc-dent',checklist:['Door dents','Fender damage','Creases & impacts','Hail damage'],steps:['Inspect damage','Metal restoration','Surface refinement','Paint match','Quality check'],ba:['svc-dent','svc-dent-after'],note:'Guaranteed workmanship · insurance friendly.'},
    paint:{head:['REMOVE IMPERFECTIONS.','RESTORE THE FINISH.'],img:'svc-paint',checklist:['Scratch removal','Swirl marks','Oxidation removal','Paint enhancement'],steps:['Wash & decon','Machine polish','Refine','Seal & protect'],ba:['svc-paint','svc-paint-after'],note:'Premium products · satisfaction guaranteed.'},
    glass:{head:['CLEAR VIEW.','SAFE DRIVE.'],img:'svc-glass',checklist:['Rock chip repair','Crack repair','Windshield replacement','Side & rear glass'],steps:['Assess damage','Isolate chip','Inject resin','Cure & polish'],ba:['svc-glass','svc-glass'],note:'Insurance often waives the deductible.'},
    detailing:{head:['CLEAN INSIDE.','CONFIDENT OUTSIDE.'],img:'svc-detailing',checklist:['Interior detail','Leather care','Carpet shampoo','Odor removal','Exterior wash'],steps:['Vacuum & prep','Deep clean','Condition & protect','Final inspect'],ba:['svc-detailing','svc-detailing'],note:'Packages from $129 to full detail $299.'},
    body:{head:['FROM MINOR DAMAGE','TO MAJOR REPAIRS.'],img:'svc-body',checklist:['Damage assessment','Parts sourcing','Repair process','Paint & finish','Quality control'],steps:['Assess & estimate','Disassembly','Repair & replace','Paint & finish','Reassembly & QC'],ba:['svc-body','svc-body'],note:'We bill the insurance direct.'},
  };
  const SVC_FEATURES=[
    ['wrench','Expert Technicians','ASE certified pros'],
    ['settings','Quality NAPA Parts','2-yr / 24k warranty'],
    ['star','Modern Equipment','Dealer-level tools'],
    ['check','Satisfaction Guaranteed','We stand behind it'],
  ];
  /* ---- per-service interactive PLATE data (mirrors the concept boards) ----
     zone   : label shown in the plate header
     metrics: [label, value, tone]  tone = ok|warn|crit  (animated "live" readout)
     ba     : [beforeLabel, afterLabel, kind]  kind picks the before→after mini SVG
     rows   : [name, price, meta]  service line items with prices  */
  /* Per-service plate config — each service gets a `title` + ordered `blocks`
     that recreate the concept boards (222). Block types:
       process : numbered steps (some checked, one active/amber)
       stages  : selectable levels (one active)
       meter   : labeled gauge with % fill
       heights : left/right readouts (suspension)
       scan    : progress ring + found issue codes
       overview: row of small part-status chips
       packages: priced tiers (one featured)
       rows    : priced line items
       recommend: single highlighted recommendation card
       estimate: price + duration summary
       damagemap: color-coded truck panels
       badges  : two small badges (insurance / warranty)  */
  const SVC_PLATE={
    diagnostics:{title:'System Scan',blocks:[
      {type:'scan',pct:78,label:'Scanning vehicle systems…'},
      {type:'issues',items:[['O2 Sensor','P0131','crit'],['EVAP System','P0442','warn'],['Misfire Cyl 3','P0303','warn']]},
      {type:'estimate',label:'Diagnostic fee',value:'$60',meta:'applied to any repair'},
    ]},
    engine:{title:'Repair Process',blocks:[
      {type:'process',steps:[['Inspect & test',1],['Compression check',1],['Replace parts',2],['Road test',0]]},
      {type:'meter',label:'Engine health',pct:64,note:'Timing belt due'},
      {type:'estimate',label:'Starting at',value:'$450',meta:'timing belt · 1 day'},
    ]},
    brakes:{title:'Service Steps',blocks:[
      {type:'process',steps:[['Inspect system',1],['Measurements',1],['Replace parts',2],['System check',0],['Road test',0]]},
      {type:'meter',label:'Brake condition',pct:72,note:'Needs attention'},
      {type:'recommend',title:'Front pads &amp; rotors',price:'$350–550',meta:'Duration 2–3 hours'},
    ]},
    suspension:{title:'Vehicle Height',blocks:[
      {type:'heights',front:'+0.5 in',rear:'+0.25 in'},
      {type:'meter',label:'Alignment status',pct:78,note:'Within tolerance'},
      {type:'overview',items:[['shocks','Shocks','ok'],['tires','Springs','ok'],['wrench','Control arms','warn'],['suspension','Ball joints','warn'],['settings','Tie rods','ok']]},
    ]},
    oil:{title:'Maintenance',blocks:[
      {type:'meter',label:'Oil life',pct:14,note:'Change due now'},
      {type:'process',steps:[['Drain & filter',2],['Refill synthetic',0],['Top off fluids',0],['Multi-point check',0]]},
      {type:'estimate',label:'Oil change + filter',value:'$55–95',meta:'30 min'},
    ]},
    tires:{title:'Tread & Balance',blocks:[
      {type:'heights',front:'4/32"',rear:'3/32"',flabel:'Tread FL',rlabel:'Tread FR'},
      {type:'meter',label:'Tread remaining',pct:38,note:'Replace soon'},
      {type:'rows',items:[['New tires (set)','$400–900','1 h'],['Mount & balance','$10/ea','45 min'],['Plug repair','$5','20 min']]},
    ]},
    dent:{title:'Repair Process',blocks:[
      {type:'process',steps:[['Inspect damage',1],['Metal restoration',2],['Surface refinement',0],['Paint match',0],['Quality check',0]]},
      {type:'estimate',label:'Estimate',value:'$250–750',meta:'Duration 1–2 days'},
      {type:'badges',items:[['check','Guaranteed workmanship'],['settings','Insurance friendly']]},
    ]},
    paint:{title:'Correction Level',blocks:[
      {type:'stages',items:[['Stage 1','Enhancement',0],['Stage 2','Correction',1],['Stage 3','Show car',0]]},
      {type:'process',steps:[['Wash & decon',1],['Machine polish',2],['Refine',0],['Seal & protect',0]]},
      {type:'estimate',label:'Starting at',value:'$199',meta:'satisfaction guaranteed'},
    ]},
    glass:{title:'Repair Type',blocks:[
      {type:'rows',items:[['Rock chip','$75','30 min'],['Crack repair','$120','45 min'],['Windshield replacement','$350+','2 h']]},
      {type:'badges',items:[['check','Insurance covered'],['settings','Lifetime warranty']]},
      {type:'estimate',label:'Most repairs',value:'$75',meta:'30–45 minutes'},
    ]},
    detailing:{title:'Detail Package',blocks:[
      {type:'packages',items:[['Basic','Interior','$129',0],['Premium','Interior + Exterior','$199',1],['Complete','Full detail','$299',0]]},
      {type:'rows',items:[['Leather conditioner','+$25','add-on'],['Odor elimination','+$50','add-on']]},
    ]},
    body:{title:'Repair Process',blocks:[
      {type:'process',steps:[['Assess & estimate',1,'1–2 days'],['Disassembly',2,'1 day'],['Repair & replace',0,'2–5 days'],['Paint & finish',0,'2–3 days'],['Reassembly & QC',0,'1 day']]},
      {type:'damagemap'},
    ]},
  };
  // gauge / meter helper
  function meterBar(pct,tone){const t=tone||(pct<30?'crit':pct<70?'warn':'ok');return `<div class="svc-meter"><div class="svc-meter__track"><i class="svc-meter__fill ${t}" style="width:${pct}%"></i></div><span class="svc-meter__pct ${t}">${pct}%</span></div>`;}
  // render one plate block
  function renderBlock(b,sv){
    switch(b.type){
      case 'process': return `<div class="svc-blk"><div class="svc-blk__t mono">${SVC_PLATE[sv.key].title||'Process'}</div>
        <div class="svc-steps">${b.steps.map((s,i)=>`<div class="svc-step ${s[1]===1?'done':''} ${s[1]===2?'active':''}"><span class="svc-step__n">${s[1]===1?svg('check',13):i+1}</span><span class="svc-step__l">${s[0]}</span>${s[2]?`<span class="svc-step__d mono">${s[2]}</span>`:''}</div>`).join('')}</div></div>`;
      case 'stages': return `<div class="svc-blk"><div class="svc-blk__t mono">Correction level</div>
        <div class="svc-stages">${b.items.map((s,i)=>`<div class="svc-stagebtn ${s[2]?'active':''}"><span class="svc-stagebtn__n">${i+1}</span><span><b>${s[0]}</b><small>${s[1]}</small></span></div>`).join('')}</div></div>`;
      case 'meter': return `<div class="svc-blk"><div class="svc-blk__t mono">${b.label}</div>${meterBar(b.pct)}${b.note?`<div class="svc-blk__note mono">${b.note}</div>`:''}</div>`;
      case 'heights': return `<div class="svc-blk"><div class="svc-blk__t mono">Vehicle height</div><div class="svc-heights"><div class="svc-h"><span class="mono">${b.flabel||'Front'}</span><b class="amber">${b.front}</b></div><div class="svc-h"><span class="mono">${b.rlabel||'Rear'}</span><b class="amber">${b.rear}</b></div></div></div>`;
      case 'scan': return `<div class="svc-blk"><div class="svc-blk__t mono">System scan</div><div class="svc-scan"><div class="svc-scan__ring" style="--p:${b.pct}"><span>${b.pct}%</span></div><div class="svc-scan__txt mono">${b.label}<span class="dot amber pulse"></span></div></div></div>`;
      case 'issues': return `<div class="svc-blk"><div class="svc-blk__t mono">Found issues</div>${b.items.map(it=>`<div class="svc-issue ${it[2]}"><span class="svc-issue__ic">⚠</span><span class="svc-issue__n">${it[0]}</span><span class="svc-issue__c mono">${it[1]}</span></div>`).join('')}</div>`;
      case 'overview': return `<div class="svc-blk"><div class="svc-blk__t mono">System overview</div><div class="svc-parts">${b.items.map(it=>`<div class="svc-part"><span class="svc-part__ic">${svg(it[0]==='shocks'?'suspension':it[0],16)||svg('wrench',16)}</span><b>${it[1]}</b><span class="svc-part__s ${it[2]} mono">${it[2]==='ok'?'Good':'Check'}</span></div>`).join('')}</div></div>`;
      case 'packages': return `<div class="svc-blk"><div class="svc-blk__t mono">Detail package</div>${b.items.map(it=>`<div class="svc-pkg ${it[3]?'active':''}"><div><b>${it[0]}</b><small>${it[1]}</small></div><span class="svc-pkg__p">${it[2]}</span></div>`).join('')}</div>`;
      case 'rows': return `<div class="svc-blk"><div class="svc-blk__t mono">Pricing</div>${b.items.map(it=>`<div class="svc-row"><div class="svc-row__l"><b>${it[0]}</b><small>${it[2]}</small></div><span class="svc-row__p">${it[1]}</span></div>`).join('')}</div>`;
      case 'recommend': return `<div class="svc-blk svc-blk--rec"><div class="svc-blk__t mono">Recommended</div><div class="svc-rec"><b>${b.title}</b><span class="svc-rec__meta mono">${b.meta}</span><span class="svc-rec__p">${b.price}</span></div></div>`;
      case 'estimate': return `<div class="svc-est"><div><span class="mono">${b.label}</span>${b.meta?`<small class="mono">${b.meta}</small>`:''}</div><b class="svc-est__v">${b.value}</b></div>`;
      case 'badges': return `<div class="svc-plate__badges">${b.items.map(it=>`<div class="svc-pbadge"><span class="amber">${svg(it[0],15)}</span>${it[1]}</div>`).join('')}</div>`;
      case 'damagemap': return `<div class="svc-blk"><div class="svc-blk__t mono">Damage map</div>${damageMap()}<div class="svc-dmg-legend">${[['light','Light'],['mod','Moderate'],['major','Major'],['repl','Replacement']].map(l=>`<span class="svc-dmg-key ${l[0]}"><i></i>${l[1]}</span>`).join('')}</div></div>`;
      default: return '';
    }
  }
  // color-coded truck top view (SVG) for the body damage map
  function damageMap(){
    return `<svg class="svc-dmg" viewBox="0 0 260 120" fill="none" aria-hidden="true">
      <rect x="30" y="18" width="200" height="84" rx="16" fill="#12151a" stroke="#2a2f36"/>
      <rect x="150" y="26" width="72" height="68" rx="10" fill="#171b20" stroke="#2a2f36"/>
      <path d="M40 40 h70 v40 h-70 z" fill="rgba(255,138,30,.28)" stroke="var(--amber)"/>
      <path d="M40 30 h56 v10 h-56 z" fill="rgba(255,91,82,.4)" stroke="#ff5b52"/>
      <path d="M112 40 h34 v40 h-34 z" fill="rgba(95,208,160,.22)" stroke="#5fd0a0"/>
      <circle cx="60" cy="102" r="9" fill="#0b0d10" stroke="#3a3f47"/><circle cx="130" cy="102" r="9" fill="#0b0d10" stroke="#3a3f47"/>
      <circle cx="60" cy="16" r="9" fill="#0b0d10" stroke="#3a3f47"/><circle cx="130" cy="16" r="9" fill="#0b0d10" stroke="#3a3f47"/>
    </svg>`;
  }
  // before → after mini diagram (chrome/amber SVG), matches concept boards
  function baSvg(kind,after){
    const chrome=after?'#6b7480':'#2a2f36', accent=after?'var(--amber)':'#ff5b52', ring=after?'#454b54':'#2a2f36';
    const spokes=(n,r1,r2,col,w)=>{let o='';for(let s=0;s<n;s++){const c=s/n*Math.PI*2;o+=`<line x1="${(60+Math.cos(c)*r1).toFixed(1)}" y1="${(41+Math.sin(c)*r1).toFixed(1)}" x2="${(60+Math.cos(c)*r2).toFixed(1)}" y2="${(41+Math.sin(c)*r2).toFixed(1)}" stroke="${col}" stroke-width="${w}" stroke-linecap="round"/>`;}return o;};
    let g='';
    if(kind==='wheel') g=`<circle cx="60" cy="41" r="30" fill="#161a1f" stroke="${ring}"/><circle cx="60" cy="41" r="15" fill="#0b0d10" stroke="${chrome}"/>${spokes(after?10:8,15,29,chrome,3)}${after?'<circle cx="53" cy="34" r="7" fill="var(--amber)" opacity=".25"/>':'<path d="M34 20 Q40 34 32 44" stroke="#ff5b52" stroke-width="1.6" fill="none" opacity=".8"/>'}`;
    else if(kind==='brake') g=`<circle cx="60" cy="41" r="28" fill="#171b20" stroke="${ring}"/><circle cx="60" cy="41" r="12" fill="#0b0d10"/>${spokes(after?30:24,13,27,chrome,.7)}<path d="M40 18 A28 28 0 0 1 88 30" stroke="${accent}" stroke-width="4" fill="none"/>`;
    else if(kind==='body') g=`<rect width="120" height="82" fill="${after?'#20252c':'#14181d'}"/>${after?'<path d="M0 20 L120 8" stroke="#eaf2ff" stroke-width="6" opacity=".12"/><path d="M0 60 L120 50" stroke="var(--amber)" stroke-width="3" opacity=".18"/>':Array.from({length:22},()=>`<line x1="${(Math.random()*120).toFixed(0)}" y1="${(Math.random()*82).toFixed(0)}" x2="${(Math.random()*120).toFixed(0)}" y2="${(Math.random()*82).toFixed(0)}" stroke="#3a3f47" stroke-width=".5" opacity=".5"/>`).join('')}`;
    else if(kind==='inspect') g=`<path d="M22 30 h50 a14 14 0 0 1 14 14 v6 a14 14 0 0 1 -14 14 h-50 z" fill="${after?'#1c2127':'#1a1e23'}" stroke="${ring}"/><ellipse cx="70" cy="47" rx="13" ry="15" fill="${after?'#dfe8f2':'#3a3f47'}" opacity="${after?'.85':'.6'}"/>${after?'<ellipse cx="66" cy="42" rx="4" ry="6" fill="#fff" opacity=".8"/>':''}`;
    else g=`<rect x="26" y="24" width="68" height="40" rx="4" fill="${after?'#1c2127':'#161a1f'}" stroke="${ring}"/>${[30,46,62,78].map(x=>`<rect x="${x}" y="16" width="10" height="12" rx="2" fill="${after?'#3a4048':'#22262c'}"/>`).join('')}<circle cx="44" cy="52" r="3" fill="${after?'#5fd0a0':'#ff5b52'}"/>`;
    return `<svg viewBox="0 0 120 82" preserveAspectRatio="none" style="width:100%;height:100%;display:block"><rect width="120" height="82" fill="#0e1013"/>${g}</svg>`;
  }
  function serviceDetail(params){
    const key=params.id||'brakes'; const sv=Store.svc(key)||S().services.find(s=>s.key===key)||S().services[0];
    const d=SVC_DETAIL[sv.key]||SVC_DETAIL.brakes;
    const p=SVC_PLATE[sv.key]||SVC_PLATE.brakes;
    const idx=S().services.findIndex(s=>s.key===sv.key);
    const prev=S().services[(idx-1+S().services.length)%S().services.length];
    const next=S().services[(idx+1)%S().services.length];
    let related=S().services.filter(s=>s.key!==sv.key&&s.category===sv.category);
    related=related.concat(S().services.filter(s=>s.key!==sv.key&&s.category!==sv.category)).slice(0,4);
    const nameUp=(SVC_NAME[sv.key]||sv.name);

    return `<div class="svc-page">
      <!-- FULL-BLEED SCENE · TEXT LEFT · LIVE PLATE RIGHT (concept-board layout) -->
      <section class="svc-stage" data-svc-stage>
        <div class="svc-stage__bg"><img src="${asset(d.img+'.jpg')}" alt="${sv.name} at Newcomb's Auto Repair"></div>
        <div class="svc-stage__vignette"></div>
        <div class="svc-stage__flash" data-flash></div>

        <div class="svc-stage__top wrap">
          <a href="#/services" class="svc-stage__back mono">${svg('back',14)} All services</a>
        </div>
        <div class="svc-stage__title-wrap">
          <div class="svc-stage__tag"><span class="dot ${sv.status_tag}"></span>${sv.category.toUpperCase()}</div>
          <h1 class="svc-stage__title">${d.head[0]}<br><span class="thin">${d.head[1]}</span></h1>
          <p class="svc-stage__note lede">${d.note}</p>
        </div>

        <!-- RIGHT GLASS PLATE -->
        <aside class="svc-plate" data-plate>
          <div class="svc-plate__head">
            <span class="svc-plate__ic"><img src="${asset('ic-'+sv.key+'.jpg')}" alt=""></span>
            <div class="svc-plate__head-txt">
              <span class="svc-plate__zone">${sv.category}</span>
              <span class="svc-plate__name">${p.title}</span>
            </div>
            <span class="svc-plate__status ${sv.status_tag}">${sv.status_tag==='ok'?'OK':sv.status_tag==='priority'?'Priority':'Attention'}</span>
          </div>
          <div class="svc-plate__body">
            ${p.blocks.map(b=>renderBlock(b,sv)).join('')}
          </div>
          <button class="btn btn--amber btn--block svc-plate__book" data-book="${sv.key}">Book this service ${svg('arrow',15)}</button>
        </aside>

        <div class="svc-stage__scroll mono">Scroll for full service details <span>▼</span></div>
      </section>

      <!-- BELOW THE FOLD -->
      <div class="wrap svc-body">
        <div class="svc-body__grid">
          <div class="svc-body__main">
            <div class="sec-head"><div><div class="eyebrow">Included</div><h2 style="margin-top:12px">What's <span class="thin">covered</span></h2></div></div>
            <ul class="svc-incl">${d.checklist.map(c=>`<li><span class="svc-incl__ic">${svg('check',15)}</span>${c}</li>`).join('')}</ul>
          </div>
          <aside class="svc-body__side">
            <div class="panel svc-proc"><div class="panel__bar"><span>SERVICE PROCESS</span><span class="live"><span class="dot amber pulse"></span>${d.steps.length} STEPS</span></div>
              <div class="panel__body">${d.steps.map((s,i)=>`<div class="svc-proc__row"><span class="svc-proc__n">${String(i+1).padStart(2,'0')}</span><span class="svc-proc__t">${s}</span></div>`).join('')}</div></div>
            <button class="btn btn--amber btn--block" data-book="${sv.key}" style="margin-top:12px">Book ${nameUp} ${svg('arrow',15)}</button>
          </aside>
        </div>

        <div class="svc-feats">${SVC_FEATURES.map(f=>`<div class="svc-feat"><span class="svc-feat__ic">${svg(f[0],22)}</span><div><b>${f[1]}</b><span>${f[2]}</span></div></div>`).join('')}</div>

        <div class="sec-head" style="margin-top:var(--s8)"><div><div class="eyebrow">Keep exploring</div><h2 style="margin-top:12px">Related <span class="thin">services</span></h2></div><a href="#/services" class="btn btn--ghost btn--sm">All services ${svg('arrow',14)}</a></div>
        <div class="svc-index svc-related">${related.map((r)=>svcTile(r,S().services.findIndex(s=>s.key===r.key))).join('')}</div>

        <div class="svc-detail__nav">
          <a href="#/service?id=${prev.key}" class="svc-detail__pn">${svg('back',14)} <span><small>Prev</small>${SVC_NAME[prev.key]||prev.name}</span></a>
          <a href="#/service?id=${next.key}" class="svc-detail__pn right"><span><small>Next</small>${SVC_NAME[next.key]||next.name}</span> ${svg('arrow',14)}</a>
        </div>
      </div>
    </div>`;
  }
  function compareStage(a,b){return `<div class="svc-stage compare svc-stage-photo" data-stage="compare"><img src="${asset(a+'.jpg')}" alt="Before"><div class="compare__after"><img src="${asset(b+'.jpg')}" alt="After"></div><div class="compare__handle" role="slider" tabindex="0" aria-label="Compare"></div><span class="compare__lab l">BEFORE</span><span class="compare__lab r">AFTER</span><span class="corner tl"></span><span class="corner tr"></span><span class="corner bl"></span><span class="corner br"></span></div>`;}

  function services(){
    return `<div class="wrap section-block"><div class="page-head"><div><div class="eyebrow">All bays</div><h2 style="margin-top:14px">SERVICES</h2><p>Twelve service scenarios — book any of them online.</p></div><a href="#/book" class="btn btn--amber btn--sm">Book a bay</a></div>
      <div class="svc-index">${S().services.map((sv,i)=>svcTile(sv,i)).join('')}</div></div>`;
  }
  function about(){
    const badges=[['users','Local &amp; Family Owned'],['check','ASE Certified'],['settings','NAPA Autocare Center'],['star','2-Year / 24k Warranty']];
    const shop=[['users','Experienced Technicians'],['settings','Quality Parts'],['check','Fair Pricing'],['star','Satisfaction Guaranteed']];
    return `<section class="pagehero">
      <div class="pagehero__bg"><img src="${asset('bg-empty-shop.jpg')}" alt="Inside Newcomb's shop"></div>
      <div class="pagehero__scrim"></div>
      <div class="pagehero__in wrap">
        <div class="about__grid">
          <div class="about__intro">
            <div class="eyebrow">Our story</div>
            <h1 class="pagehero__title">ABOUT<br><span class="thin">NEWCOMB'S</span></h1>
            <p class="lede" style="margin-top:18px">Honest work. Real people. Solid results.</p>
            <p class="dim" style="margin-top:14px;line-height:1.7;max-width:38ch">Newcomb's Auto Repair has been Drakes Branch's trusted choice for quality auto repair and maintenance since day one. A father &amp; son operation combining old-school values with modern technology.</p>
            <div class="about__badges">${badges.map(b=>`<div class="about__badge"><span class="about__badge-ic">${svg(b[0],20)}</span><b>${b[1]}</b></div>`).join('')}</div>
          </div>
          <aside class="about__shop panel">
            <div class="panel__bar"><span>OUR SHOP</span></div>
            <div class="panel__body">
              <p class="dim" style="margin:0 0 16px;font-size:13px;line-height:1.6">We combine old-school values with modern technology to deliver the best service possible.</p>
              ${shop.map(x=>`<div class="about__row"><span class="about__ic">${svg(x[0],17)}</span>${x[1]}</div>`).join('')}
              <a href="#/services" class="btn btn--ghost btn--block" style="margin-top:16px">View our services ${svg('arrow',14)}</a>
            </div>
          </aside>
        </div>
      </div>
    </section>`;
  }
  function reviews(){
    return `<div class="wrap section-block"><div class="page-head"><div><div class="eyebrow">Real feedback</div><h2 style="margin-top:14px">REVIEWS</h2></div>
      <div style="text-align:right"><div class="disp" style="font-size:44px">4.9 <span class="amber">★★★★★</span></div><div class="tag">Based on 187 reviews</div></div></div>
      <div class="rev-grid">${S().reviews.map(r=>`<div class="rev"><div class="stars">${'★'.repeat(r.rating)}${'☆'.repeat(5-r.rating)}</div><p>"${r.text}"</p><b>${r.name}</b></div>`).join('')}</div>
      <div style="margin-top:24px"><button class="btn btn--ghost" onclick="Pages.writeReview()">Write a review</button></div></div>`;
  }
  function gallery(){
    return `<div class="wrap section-block"><div class="eyebrow">Our work</div><h2 style="margin:14px 0 20px">GALLERY</h2>
      <div class="gal-grid">${S().gallery.map(g=>`<img src="${asset(g+'.jpg')}" alt="Work sample" loading="lazy">`).join('')}</div></div>`;
  }
  function contact(){
    const s=S().shop;
    return `<section class="contact">
      <div class="contact__map"><img src="${asset('map-dark.jpg')}" alt="Shop location map"><span class="contact__pin">${svg('pin',30)}</span></div>
      <div class="contact__scrim"></div>
      <div class="contact__in wrap">
        <div class="contact__info">
          <div class="eyebrow">Get in touch</div>
          <h1 class="contact__title">CONTACT<br><span class="thin">Get in touch</span></h1>
          <p class="dim" style="margin:14px 0 26px">Questions? We're here to help.</p>
          <a href="tel:${s.phone}" class="contact__row"><span class="contact__ic">${svg('phone',18)}</span><div><b>Call us</b><span>${window.telFmt(s.phone)}</span></div></a>
          <div class="contact__row"><span class="contact__ic">${svg('pin',18)}</span><div><b>Visit us</b><span>${s.addr}</span></div></div>
          <div class="contact__row"><span class="contact__ic">${svg('history',18)}</span><div><b>Hours</b><span>${s.hours}</span></div></div>
          <div class="contact__follow"><span class="mono">Follow us</span><a href="#" onclick="return false">f</a><a href="#" onclick="return false">◎</a><a href="#" onclick="return false">G</a></div>
        </div>
        <form class="contact__form panel" onsubmit="Pages.submitContact(event)">
          <div class="panel__bar"><span>SEND US A MESSAGE</span></div>
          <div class="panel__body">
            <div class="field"><input required name="name" placeholder="Your name"></div>
            <div class="field"><input name="phone" placeholder="Phone number"></div>
            <div class="field"><input type="email" name="email" placeholder="Email address"></div>
            <div class="field"><textarea rows="4" name="message" placeholder="Message"></textarea></div>
            <button class="btn btn--amber btn--block">Send message ${svg('arrow',15)}</button>
          </div>
        </form>
      </div>
    </section>`;
  }
  function specials(){
    return `<section class="pagehero pagehero--top">
      <div class="pagehero__bg"><img src="${asset('bg-empty-shop.jpg')}" alt="Newcomb's shop"></div>
      <div class="pagehero__scrim"></div>
      <div class="pagehero__in wrap">
        <div class="eyebrow">Current offers</div>
        <h1 class="pagehero__title">SPECIALS<br><span class="thin">Current offers</span></h1>
        <p class="dim" style="margin-top:14px">Quality service. Special pricing. Limited time.</p>
        <div class="specials__grid">${S().specials.map(sp=>`<div class="special"><b class="special__amt">${sp.title}</b><div class="special__for">${sp.sub}</div><div class="special__note">${sp.note}</div><div class="special__exp mono">EXP: ${sp.exp}</div><button class="btn btn--amber btn--sm btn--block" style="margin-top:16px" onclick="Pages.claimSpecial('${sp.sub}')">Claim offer</button></div>`).join('')}</div>
        <div style="margin-top:var(--s6)"><a href="#/services" class="btn btn--ghost">View all services ${svg('arrow',14)}</a></div>
      </div>
    </section>`;
  }
  function financing(){
    const perks=[['check','Quick Approval'],['check','Low Monthly Payments'],['check','No Hidden Fees'],['check','Multiple Options']];
    return `<section class="pagehero financing">
      <div class="pagehero__bg"><img src="${asset('bg-empty-shop.jpg')}" alt="Newcomb's shop"></div>
      <div class="pagehero__scrim"></div>
      <div class="pagehero__in wrap">
        <div class="financing__grid">
          <div class="financing__left">
            <div class="eyebrow">Flexible options</div>
            <h1 class="pagehero__title">FINANCING<br><span class="thin">Flexible options</span></h1>
            <p class="dim" style="margin:16px 0 20px">Get the service you need today. Pay over time.</p>
            ${perks.map(p=>`<div class="financing__perk"><span class="amber">${svg(p[0],16)}</span>${p[1]}</div>`).join('')}
          </div>
          <div class="calc panel">
            <div class="panel__bar"><span>FINANCING CALCULATOR</span></div>
            <div class="panel__body">
              <div class="field"><label>Service amount · <span id="amtV" class="amber">$1,000</span></label><input type="range" id="amt" min="150" max="6000" value="1000" step="50" oninput="Pages.calc()"></div>
              <div class="field"><label>Term</label><select id="term" onchange="Pages.calc()"><option value="6">6 Months</option><option value="12" selected>12 Months</option><option value="24">24 Months</option><option value="36">36 Months</option></select></div>
              <div class="tag" style="margin-top:8px">EST. MONTHLY PAYMENT</div>
              <div class="calc__val" id="pay">$94<span style="font-size:16px;color:var(--faint)">/mo</span></div>
              <button class="btn btn--amber btn--block" style="margin-top:16px" onclick="Pages.applyFinancing()">Apply now</button>
              <div class="tag" style="margin-top:10px;color:var(--faint)">*Subject to credit approval</div>
            </div>
          </div>
        </div>
      </div>
      <div class="financing__partners"><span class="mono faint">Financing partners</span>${['snap!','synchrony','acima'].map(n=>`<span class="financing__partner">${n}</span>`).join('')}</div>
    </section>`;
  }
  function warranty(){
    return `<div class="wrap section-block"><div class="eyebrow">Peace of mind</div><h2 style="margin:14px 0 20px">WARRANTY</h2>
      <div class="two-col">
        <div><p class="lede">We stand behind our work. All repairs are backed by our 2-year / 24,000-mile warranty for your peace of mind.</p>
          <ul style="margin-top:20px;display:flex;flex-direction:column;gap:12px">
            ${['2-Year / 24K Mile Warranty','Nationwide Coverage','Quality Parts & Labor','No-Hassle Claims'].map(x=>`<li class="row gap3"><span class="amber">${svg('check',18)}</span>${x}</li>`).join('')}
          </ul></div>
        <div class="card" style="display:grid;place-items:center;padding:40px;background:var(--s900)">
          <div style="width:170px;height:170px;border-radius:50%;border:2px solid var(--amber);display:grid;place-items:center;text-align:center">
            <div><div class="disp amber" style="font-size:40px;line-height:1">2 YEAR</div><div class="disp" style="font-size:20px">24,000 MI</div><div style="margin-top:8px" class="amber">${svg('check',26)}</div></div>
          </div></div>
      </div></div>`;
  }
  function faq(){
    return `<div class="wrap section-block" style="max-width:820px"><div class="eyebrow">Answers</div><h2 style="margin:14px 0 20px">FAQ</h2>
      ${S().faqs.map(([q,a])=>`<div class="faq-item"><div class="faq-q" onclick="this.parentElement.classList.toggle('open')">${q} ${svg('arrow',16).replace('M5 12h14M13 6l6 6-6 6','M6 9l6 6 6-6')}</div><div class="faq-a"><div style="padding:0 16px 16px">${a}</div></div></div>`).join('')}
      <div class="card" style="padding:20px;margin-top:20px;text-align:center"><p class="dim">Still have questions?</p><a href="#/contact" class="btn btn--amber btn--sm" style="margin-top:12px">Contact us ${svg('arrow',14)}</a></div></div>`;
  }
  /* ============================================================
     UI KIT — single source of truth for the design system
     ============================================================ */
  function uikit(){
    const iconKeys=['home','dash','order','car','history','chat','tasks','users','calendar','inventory','reports','settings','check','arrow','back','phone','pin','tow','plus','bolt','star','book','wrench'];
    const surfaces=[['--black','#0a0b0c'],['--oily','#0d0e10'],['--s900','#121417'],['--s800','#1b1f24'],['--s700','#242931'],['--s600','#31383f']];
    const inks=[['--text','Text'],['--dim','Dim'],['--faint','Faint'],['--ghost','Ghost']];
    const brand=[['--amber','Amber'],['--amber2','Amber 2'],['--ok','Green'],['--info','Blue'],['--yellow','Yellow'],['--crit','Red']];
    const sw=(v,label)=>`<div class="uk-sw"><span class="uk-sw__chip" style="background:${v.startsWith('--')?`var(${v})`:v}"></span><b>${label||v}</b><code>${v}</code></div>`;
    const glass=(title,tag,body,cls)=>`<div class="uk-glass ${cls||''}"><div class="uk-glass__sheen"></div><div class="uk-glass__h"><span>${title}</span>${tag?`<span class="uk-glass__tag">${tag}</span>`:''}</div><div class="uk-glass__b">${body}</div></div>`;
    const sect=(id,n,title,sub,body)=>`<section class="uk-sect" id="${id}"><div class="uk-sect__h"><span class="uk-sect__n mono">${n}</span><div><h2>${title}</h2>${sub?`<p>${sub}</p>`:''}</div></div>${body}</section>`;

    return `<div class="uk">
      <div class="uk-aurora"></div>
      <header class="uk-hero">
        <div class="uk-hero__badge mono">${svg('wrench',13)} Design system · v1.0</div>
        <h1 class="uk-hero__title">UI <span class="amber">KIT</span></h1>
        <p class="uk-hero__sub">A glassmorphic garage-grade design language — brushed metal, amber neon and frosted glass. Every screen in the app is built from these parts.</p>
        <nav class="uk-tabs">${[['tokens','Tokens'],['type','Type'],['buttons','Buttons'],['status','Status'],['forms','Forms'],['icons','Icons'],['data','Data'],['portal','Service'],['ai','AI']].map(t=>`<a href="#uk-${t[0]}">${t[1]}</a>`).join('')}</nav>
      </header>

      ${sect('uk-tokens','01','Foundation','Color, surface & elevation tokens — the single source of truth.',`
        <div class="uk-grid uk-grid--4">
          ${glass('Surfaces','8 tiers',`<div class="uk-sws">${surfaces.map(x=>sw(x[0],x[0])).join('')}</div>`)}
          ${glass('Ink','text',`<div class="uk-sws">${inks.map(x=>sw(x[0],x[1])).join('')}</div>`)}
          ${glass('Brand &amp; status','accent',`<div class="uk-sws">${brand.map(x=>sw(x[0],x[1])).join('')}</div>`)}
          ${glass('Radius &amp; glass','frosted',`<div class="uk-radii">${[['r1','5'],['r2','9'],['r3','14'],['pill','∞']].map(r=>`<div class="uk-radius" style="border-radius:var(--${r[0]==='pill'?'r-pill':r[0]})">${r[0]}</div>`).join('')}</div><div class="uk-glasschip" style="margin-top:12px">frosted glass tile</div>`)}
        </div>`)}

      ${sect('uk-type','02','Typography','Oswald display · Inter body · JetBrains Mono data.',
        glass('Type scale',null,`
          <div class="uk-type">
            <div class="uk-type__row"><span class="uk-type__lab mono">H1 · OSWALD</span><h1 style="margin:0;font-size:52px">Honest work.</h1></div>
            <div class="uk-type__row"><span class="uk-type__lab mono">H2</span><h2 style="margin:0">Solid results</h2></div>
            <div class="uk-type__row"><span class="uk-type__lab mono">H3</span><h3 style="margin:0">Service order</h3></div>
            <div class="uk-type__row"><span class="uk-type__lab mono">LEDE</span><p class="lede" style="margin:0">Larger intro copy that sets the tone under a heading.</p></div>
            <div class="uk-type__row"><span class="uk-type__lab mono">BODY</span><p style="margin:0">Default reading size used across paragraphs and descriptions.</p></div>
            <div class="uk-type__row"><span class="uk-type__lab mono">MONO</span><p class="mono" style="margin:0;color:var(--amber)">NCAR-2024-0587 · 540-516-0196</p></div>
          </div>`))}

      ${sect('uk-buttons','03','Buttons','Frosted, tactile, with amber glow on primary.',`
        <div class="uk-grid uk-grid--3">
          ${glass('Primary &amp; ghost',null,`<div class="uk-row"><button class="btn btn--amber">${svg('book',15)} Book service</button><button class="btn btn--ghost">${svg('phone',15)} Call us</button></div><div class="uk-row" style="margin-top:12px"><button class="btn btn--amber btn--sm">Small ${svg('arrow',14)}</button><button class="btn btn--ghost btn--sm">${svg('plus',14)} New</button></div>`)}
          ${glass('Icon buttons',null,`<div class="uk-row">${['phone','chat','tow','settings','plus'].map(k=>`<button class="uk-iconbtn">${svg(k,18)}</button>`).join('')}</div>`)}
          ${glass('Block',null,`<button class="btn btn--amber btn--block">Continue ${svg('arrow',15)}</button><button class="btn btn--ghost btn--block" style="margin-top:10px">Secondary</button>`)}
        </div>`)}

      ${sect('uk-status','04','Status &amp; identity','Badges, pills, dots and avatars.',`
        <div class="uk-grid uk-grid--2">
          ${glass('Badges &amp; pills',null,`<div class="uk-row" style="margin-bottom:12px"><span class="badge ok">${svg('check',12)} OK</span><span class="badge warn">Attention</span><span class="badge crit">Critical</span><span class="badge info">Info</span></div><div class="uk-row"><span class="pill progress">In Progress</span><span class="pill inspection">Inspection</span><span class="pill pending">Pending</span><span class="pill completed">Completed</span></div>`)}
          ${glass('Dots &amp; avatars',null,`<div class="uk-row" style="margin-bottom:14px"><span class="uk-inline"><span class="dot ok"></span>Good</span><span class="uk-inline"><span class="dot warn"></span>Warn</span><span class="uk-inline"><span class="dot crit"></span>Critical</span><span class="uk-inline"><span class="dot amber pulse"></span>Live</span></div><div class="uk-row" style="align-items:center">${['av-1','av-2','av-3','av-4'].map(a=>`<span class="avatar" style="width:42px;height:42px"><img src="${asset(a+'.jpg')}" alt=""></span>`).join('')}<span class="avatar avatar--i" style="width:42px;height:42px">JS</span></div>`)}
        </div>`)}

      ${sect('uk-forms','05','Form controls',null,`
        <div class="uk-grid uk-grid--2">
          ${glass('Inputs',null,`<div class="field"><label>Text field</label><input placeholder="Your name"></div><div class="field" style="margin-top:12px"><label>Select</label><select><option>Dent Repair</option><option>Brake Service</option></select></div>`)}
          ${glass('Textarea &amp; range',null,`<div class="field"><label>Message</label><textarea rows="2" placeholder="Type here…"></textarea></div><div class="field" style="margin-top:12px"><label>Service amount · <span class="amber">$1,000</span></label><input type="range" min="0" max="100" value="55"></div>`)}
        </div>`)}

      ${sect('uk-icons','06','Icon set','Unified lucide-style stroke icons on frosted tiles.',
        `<div class="uk-icons">${iconKeys.map(k=>`<div class="uk-ic"><span class="uk-ic__g">${svg(k,22)}</span><code>${k}</code></div>`).join('')}</div>`)}

      ${sect('uk-data','07','Data display','Panels, stat cards, meters & the progress tracker.',`
        <div class="uk-grid uk-grid--2" style="margin-bottom:14px">
          <div class="uk-stat"><span class="uk-stat__ic">${svg('order',20)}</span><div><b>124</b><span>Total orders</span></div><span class="uk-stat__d">+12%</span></div>
          <div class="uk-stat uk-stat--amber"><span class="uk-stat__ic">${svg('wrench',20)}</span><div><b>38</b><span>In progress</span></div><span class="uk-stat__d">+8%</span></div>
        </div>
        ${glass('Order table',null,`<table class="tbl"><thead><tr><th>Order #</th><th>Customer</th><th>Status</th></tr></thead><tbody>
          <tr><td class="id">NCAR-2024-0587</td><td><div class="cell-user">${avatarEl(S().customers[0],26)}<b style="color:var(--text)">John Smith</b></div></td><td><span class="pill progress">In Progress</span></td></tr>
          <tr><td class="id">NCAR-2024-0585</td><td><div class="cell-user">${avatarEl(S().customers[2],26)}<b style="color:var(--text)">Mike Brown</b></div></td><td><span class="pill completed">Completed</span></td></tr>
        </tbody></table>`)}
        <div class="uk-grid uk-grid--2" style="margin-top:14px">
          ${glass('Meter',null,`<div class="svc-meter"><div class="svc-meter__track"><i class="svc-meter__fill warn" style="width:72%"></i></div><span class="svc-meter__pct warn">72%</span></div>`)}
          ${glass('Progress tracker',null,`<div class="tracker">${['Received','Inspection','In Progress','QC','Ready'].map((st,i)=>`<div class="tstep ${i<2?'done':''} ${i===2?'active':''}"><div class="tnode">${i<2?svg('check',14):i+1}</div><div class="tlab">${st}</div></div>`).join('')}</div>`)}
        </div>`)}

      ${sect('uk-portal','08','Service components',null,`
        <div class="uk-grid uk-grid--3">
          ${glass('Service steps',null,`<div class="svc-steps"><div class="svc-step done"><span class="svc-step__n">${svg('check',13)}</span><span class="svc-step__l">Inspect</span></div><div class="svc-step active"><span class="svc-step__n">2</span><span class="svc-step__l">Replace parts</span></div></div>`)}
          ${glass('Priced row',null,`<div class="svc-row"><div class="svc-row__l"><b>Pads + rotors</b><small>2–3 h</small></div><span class="svc-row__p">$350–550</span></div><div class="svc-row"><div class="svc-row__l"><b>Fluid flush</b><small>45 min</small></div><span class="svc-row__p">$120</span></div>`)}
          ${glass('Estimate',null,`<div class="svc-est"><div><span class="mono">Estimate</span><small class="mono">Duration 1–2 days</small></div><b class="svc-est__v">$250–750</b></div>`)}
        </div>`)}

      ${sect('uk-ai','09','AI agent',null,
        glass('Superagent chip',null,`<div class="uk-ai"><span class="uk-ai__orb"><span class="dot ok"></span></span><div><b>Ask AI</b><p class="mono faint">Books jobs · dispatches tows · answers FAQ</p></div><button class="btn btn--amber btn--sm">Open ${svg('arrow',14)}</button></div>`))}

      <footer class="uk-foot mono">Newcomb's Auto Repair — glassmorphic garage UI · every component is inlined, zero external assets.</footer>
    </div>`;
  }

  function book(){
    const opts=S().services.map(sv=>`<option value="${sv.key}">${SVC_NAME[sv.key]||sv.name}</option>`).join('');
    return `<section class="book">
      <div class="book__bg"><img src="${asset('hub.jpg')}" alt="Ford F-150 in the shop"></div>
      <div class="book__scrim"></div>
      <div class="book__in wrap">
        <div class="book__copy">
          <div class="eyebrow amber">09 · Reserve a bay</div>
          <h1 class="book__title">BOOK<br><span class="thin">Your service</span></h1>
          <p class="dim" style="margin:14px 0 22px">Your truck. Our priority.</p>
          <div class="book__perk"><span class="amber">${svg('check',16)}</span>Fast response guaranteed</div>
          <div class="book__perk"><span class="amber">${svg('check',16)}</span>Customer satisfaction</div>
          <div class="book__perk"><span class="amber">${svg('check',16)}</span>Easy online booking</div>
        </div>
        <form class="book__form panel" onsubmit="Pages.submitBook(event)">
          <div class="panel__bar"><span>SCHEDULE APPOINTMENT</span></div>
          <div class="panel__body">
            <div class="field"><label>Service</label><select name="service">${opts}</select></div>
            <div class="field-row"><div class="field"><label>Date</label><input type="date" name="date"></div><div class="field"><label>Time</label><select name="time"><option>8:00 AM</option><option>10:00 AM</option><option>1:00 PM</option><option>3:00 PM</option></select></div></div>
            <div class="field"><label>Vehicle</label><input name="vehicle" placeholder="Year / Make / Model"></div>
            <div class="field"><label>Phone</label><input name="phone" placeholder="Your phone number"></div>
            <button class="btn btn--amber btn--block">Confirm appointment ${svg('arrow',15)}</button>
            <button type="button" class="btn btn--ghost btn--block" style="margin-top:8px" onclick="Flows.booking()">Or use the guided flow</button>
          </div>
        </form>
      </div>
    </section>`;
  }

  /* ---------------- CLIENT PORTAL ---------------- */
  function portalHome(){
    const c=Store.cust('c1'); const o=S().orders[0]; const v=Store.veh(o.vehicle); const sv=Store.svc(o.service); const tch=Store.tech(o.technician);
    const steps=['Received','Inspection','In Progress','Quality Check','Ready'];
    const vs=S().vehicles.filter(x=>x.customer==='c1');
    const hist=S().serviceHistory;
    return `<div class="page-head"><div class="page-head__l">${avatarEl(c,52)}<div><div class="eyebrow">Welcome back</div><h1 style="margin-top:6px">Hi, ${c.name.split(' ')[0]}</h1><p>Here's what's happening with your vehicles.</p></div></div><button class="btn btn--amber btn--sm" data-book>${svg('book',15)} Book service</button></div>

    <div class="portal-stats">
      <div class="pstat"><span class="pstat__ic">${svg('car',18)}</span><div><b>${vs.length}</b><span>Vehicles</span></div></div>
      <div class="pstat"><span class="pstat__ic amber">${svg('wrench',18)}</span><div><b>1</b><span>Active order</span></div></div>
      <div class="pstat"><span class="pstat__ic">${svg('history',18)}</span><div><b>${hist.length}</b><span>Total services</span></div></div>
      <div class="pstat"><span class="pstat__ic">${svg('reports',18)}</span><div><b>$1,001</b><span>Lifetime spend</span></div></div>
    </div>

    <div class="dash-grid">
      <div class="panel panel--active"><div class="panel__bar"><span>ACTIVE ORDER · ${o.number}</span><span class="live"><span class="dot amber pulse"></span>${o.progress}%</span></div>
        <div class="panel__body">
          <div class="active-order">
            <img class="active-order__img" src="${asset('vehicle-f150.jpg')}" alt="${v.year} ${v.make} ${v.model}">
            <div class="active-order__info">
              <div class="between" style="align-items:flex-start"><div><b class="disp" style="font-size:20px">${sv.name}</b><div class="mono faint" style="margin-top:4px">${v.year} ${v.make} ${v.model} · ${v.plate}</div></div><span class="pill ${o.status.toLowerCase().replace(/ /g,'')}">${o.status}</span></div>
              <div class="row gap3" style="margin-top:12px">${avatarEl(tch,28)}<div class="mono faint" style="font-size:11px">Advisor · <b style="color:var(--text)">${tch.name}</b></div></div>
            </div>
          </div>
          <div class="tracker">${steps.map((st,i)=>`<div class="tstep ${i<o.stage-1?'done':''} ${i===o.stage-1?'active':''}"><div class="tnode">${i<o.stage-1?svg('check',15):i+1}</div><div class="tlab">${st}</div></div>`).join('')}</div>
          <div class="row gap2" style="margin-top:18px"><a href="#/portal/order" class="btn btn--amber btn--sm">Track order ${svg('arrow',14)}</a><a href="#/portal/chat" class="btn btn--ghost btn--sm">${svg('chat',14)} Message advisor</a></div>
        </div></div>
      <div class="portal-aside">
        <div class="panel"><div class="panel__bar"><span>QUICK ACTIONS</span></div><div class="panel__body">
          <div class="quick-actions" style="margin-top:0">
            <button class="qa" data-book>${svg('book',22)}<span>Book</span></button>
            <a class="qa" href="#/portal/garage">${svg('car',22)}<span>Garage</span></a>
            <a class="qa" href="#/portal/history">${svg('history',22)}<span>History</span></a>
            <button class="qa" onclick="Flows.tow()">${svg('tow',22)}<span>Tow</span></button>
          </div></div></div>
        <div class="panel"><div class="panel__bar"><span>MY GARAGE</span><a href="#/portal/garage" class="live">All →</a></div><div class="panel__body mini-list">
          ${vs.map((x,i)=>`<a class="glist" href="#/portal/garage"><span class="glist__ic">${svg('car',18)}</span><div class="m"><b style="font-size:13px">${x.year} ${x.make} ${x.model}</b><span class="faint mono" style="font-size:10px">${(x.mileage||0).toLocaleString()} mi · ${x.plate}</span></div>${i===0?'<span class="badge warn" style="font-size:8px">ACTIVE</span>':svg('arrow',14)}</a>`).join('')}
        </div></div>
      </div>
    </div>`;
  }

  function portalOrder(){
    const o = S().orders[0]; const v=Store.veh(o.vehicle),c=Store.cust(o.customer),sv=Store.svc(o.service),tch=Store.tech(o.technician);
    const steps=['Received','Inspection','In Progress','Quality Check','Ready'];
    const updates=Store.updatesFor(o.number);
    return `<div class="page-head"><div><div class="eyebrow">Order ${o.number}</div><h1 style="margin-top:10px">MY SERVICE ORDER</h1><p>${v.year} ${v.make} ${v.model} · ${sv.name}</p></div><span class="pill ${o.status.toLowerCase().replace(' ','')}"><span class="dot ${o.status==='Completed'?'ok':'warn'}"></span>${o.status}</span></div>
    <div class="dash-grid">
      <div class="panel"><div class="panel__bar"><span>ORDER PROGRESS</span><span class="live"><span class="dot amber pulse"></span>${o.progress}%</span></div>
        <div class="panel__body">
          <div class="tracker">${steps.map((st,i)=>`<div class="tstep ${i<o.stage-1?'done':''} ${i===o.stage-1?'active':''}"><div class="tnode">${i<o.stage-1?svg('check',15):i+1}</div><div class="tlab">${st}</div></div>`).join('')}</div>
          <div class="meter" style="margin-top:8px"><i style="width:${o.progress}%"></i></div>
          <div style="margin-top:22px" class="tag">SERVICE UPDATES · LIVE FROM THE BAY</div>
          <div class="timeline" style="margin-top:14px">${updates.slice().reverse().map(u=>`<div class="tl-item"><div class="tl-time">${window.fmtDate(u.created_date)} · ${window.fmtTime(u.created_date)}</div><div class="tl-msg">${u.message}</div>${u.photos&&u.photos.length?`<div class="tl-photos">${u.photos.map(p=>`<img src="${asset(p+'.jpg')}" alt="Bay photo" loading="lazy">`).join('')}</div>`:''}</div>`).join('')||'<p class="dim">No updates yet.</p>'}</div>
          <div class="row gap3" style="margin-top:14px"><a href="#/portal/chat" class="btn btn--amber btn--sm">${svg('chat',15)} Chat with advisor</a></div>
        </div></div>
      <div style="display:flex;flex-direction:column;gap:12px">
        <div class="panel"><div class="panel__bar"><span>VEHICLE</span></div><div class="panel__body"><img src="${asset('vehicle-f150.jpg')}" alt="${v.year} ${v.make} ${v.model}" style="width:100%;height:150px;object-fit:cover;border-radius:var(--r1);border:1px solid var(--line);margin-bottom:12px"><b class="disp" style="font-size:18px">${v.year} ${v.make} ${v.model}</b><div class="mono faint" style="margin-top:8px;line-height:1.9">Plate: ${v.plate}<br>Color: ${v.color}<br>VIN: ${v.vin||'—'}</div></div></div>
        <div class="panel"><div class="panel__bar"><span>SERVICE ADVISOR</span></div><div class="panel__body"><div class="row gap3">${avatarEl(tch,44)}<div><b>${tch.name}</b><div class="mono faint">${tch.role} · ${window.telFmt(S().shop.phone)}</div></div></div></div></div>
        <div class="panel"><div class="panel__bar"><span>ESTIMATE</span>${o.approval?`<span class="badge ${o.approval==='approved'?'ok':'crit'}">${o.approval}</span>`:'<span class="badge warn">awaiting you</span>'}</div><div class="panel__body"><div class="between mono" style="padding:6px 0"><span class="faint">Labor</span><b>${window.fmtMoney(o.estimate_labor)}</b></div><div class="between mono" style="padding:6px 0"><span class="faint">Parts</span><b>${o.estimate_parts?window.fmtMoney(o.estimate_parts):'Included'}</b></div><div class="between mono" style="padding:10px 0;border-top:1px solid var(--line);margin-top:6px"><span>Total</span><b class="amber disp" style="font-size:22px">${window.fmtMoney(o.estimate_total)}</b></div>
          ${o.approval?`<p class="mono faint" style="margin-top:12px">${o.approval==='approved'?'✓ Work authorized — thanks!':'Declined — an advisor will reach out.'}</p>`:`<div class="row gap2" style="margin-top:14px"><button class="btn btn--amber btn--sm btn--block" onclick="Pages.approve('${o.number}','approved')">${svg('check',14)} Approve</button><button class="btn btn--ghost btn--sm" onclick="Pages.approve('${o.number}','declined')">Decline</button></div><p class="mono faint" style="margin-top:10px;font-size:9px">⚡ Approving fires A11 · work authorization</p>`}</div></div>
      </div>
    </div>`;
  }
  let garageSel=null;
  // maintenance intervals → recommendations (drives A7 reminder automation)
  function maintenance(v){
    const m=v.mileage||0;
    const items=[
      {name:'Oil Change',every:5000,ic:'oil'},
      {name:'Tire Rotation',every:6000,ic:'car'},
      {name:'Brake Inspection',every:12000,ic:'wrench'},
      {name:'Air Filter',every:15000,ic:'settings'},
      {name:'Timing Belt',every:100000,ic:'wrench'},
    ];
    return items.map(it=>{const next=Math.ceil(m/it.every)*it.every; let due=next-m; if(due===0)due=it.every;
      const status=due<400?'crit':due<1500?'warn':'ok';
      return {...it, next, due, status};
    }).sort((a,b)=>a.due-b.due);
  }
  function portalGarage(){
    const vs=S().vehicles.filter(v=>v.customer==='c1');
    garageSel=garageSel&&vs.find(v=>v.id===garageSel)?garageSel:vs[0].id;
    return `<div class="page-head"><div><div class="eyebrow">Your vehicles</div><h1 style="margin-top:10px">MY GARAGE</h1><p>${vs.length} vehicles on file — select one for details &amp; upcoming maintenance</p></div><button class="btn btn--amber btn--sm" onclick="toast('Add vehicle — form on live build')">${svg('plus',15)} Add vehicle</button></div>
    <div class="veh-grid">
      <div class="veh-list">${vs.map((v,i)=>`<button class="veh-card ${v.id===garageSel?'sel':''}" onclick="Pages.garagePick('${v.id}')"><span class="veh-card__ic">${svg('car',20)}</span><div class="veh-card__b"><b>${v.year} ${v.make} ${v.model}</b><div class="meta">${v.color} · ${v.plate}<br>${(v.mileage||0).toLocaleString()} mi</div>${i===0?'<span class="veh-card__tag"><span class="dot amber pulse"></span>ACTIVE ORDER</span>':''}</div></button>`).join('')}</div>
      <div id="garageDetail">${garageDetail(vs.find(v=>v.id===garageSel))}</div>
    </div>`;
  }
  function garageDetail(v){
    const rec=maintenance(v);
    return `
      <div class="panel"><div class="panel__bar"><span>VEHICLE DETAILS</span><a href="#/portal/history" class="live">Service history →</a></div>
        <div class="panel__body"><div class="veh-detail"><img src="${asset('vehicle-f150.jpg')}" alt="${v.year} ${v.make} ${v.model}" class="veh-detail__img">
          <div class="veh-specs">${[['Color',v.color],['Plate',v.plate],['Mileage',(v.mileage||0).toLocaleString()+' mi'],['VIN',v.vin||'—']].map(s=>`<div class="veh-spec"><span>${s[0]}</span><b>${s[1]}</b></div>`).join('')}</div></div></div></div>
      <div class="panel" style="margin-top:12px"><div class="panel__bar"><span>UPCOMING MAINTENANCE</span><span class="live"><span class="dot amber"></span>A7 reminders</span></div>
        <div class="panel__body">${rec.slice(0,4).map(r=>`<div class="between" style="padding:11px 0;border-bottom:1px solid var(--line)"><div class="row gap3"><span class="dot ${r.status}"></span><div><b class="disp" style="font-size:14px;text-transform:uppercase">${r.name}</b><div class="mono faint" style="font-size:10px">Due in ${r.due.toLocaleString()} mi · every ${(r.every/1000)}k</div></div></div><button class="btn ${r.status==='crit'?'btn--amber':'btn--ghost'} btn--sm" data-book="${r.name.toLowerCase().includes('oil')?'oil':r.name.toLowerCase().includes('brake')?'brakes':r.name.toLowerCase().includes('tire')?'tires':''}">Book</button></div>`).join('')}
          <button class="btn btn--ghost btn--sm btn--block" style="margin-top:12px" onclick="Pages.remindMe('${v.id}')">${svg('history',14)} Remind me automatically</button></div></div>
      <div class="quick-actions">
        <button class="qa" data-book>${svg('book',22)}<span>Book Service</span></button>
        <a class="qa" href="#/portal/order">${svg('order',22)}<span>View Orders</span></a>
        <a class="qa" href="#/portal/history">${svg('history',22)}<span>History</span></a>
        <button class="qa" onclick="toast('Records exported')">${svg('reports',22)}<span>Records</span></button>
      </div>`;
  }
  function portalHistory(){
    return `<div class="page-head"><div><div class="eyebrow">2020 Ford F-150 XLT</div><h1 style="margin-top:10px">SERVICE HISTORY</h1></div><button class="btn btn--ghost btn--sm" onclick="toast('All records downloaded')">Download records</button></div>
    <div class="dash-grid">
      <div class="panel"><div class="panel__bar"><span>ALL SERVICES</span><span>${S().serviceHistory.length} records</span></div>
        <table class="tbl"><thead><tr><th>Date</th><th>Service</th><th>Mileage</th><th>Total</th><th>Status</th></tr></thead>
        <tbody>${S().serviceHistory.map(h=>`<tr><td>${window.fmtDate(h.date)}</td><td style="color:var(--text)">${h.service}</td><td>${h.mileage.toLocaleString()} mi</td><td>${window.fmtMoney(h.total)}</td><td><span class="pill ${h.status.toLowerCase().replace(' ','')}">${h.status}</span></td></tr>`).join('')}</tbody></table></div>
      <div class="panel"><div class="panel__bar"><span>SERVICE SUMMARY</span></div><div class="panel__body">
        <div class="between mono" style="padding:8px 0"><span class="faint">Total services</span><b class="disp" style="font-size:24px">6</b></div>
        <div class="between mono" style="padding:8px 0"><span class="faint">Total spent</span><b class="disp amber" style="font-size:24px">$1,001.40</b></div>
        <div class="between mono" style="padding:8px 0"><span class="faint">Customer since</span><b>Jul 2023</b></div>
        <div class="tag" style="margin-top:16px">RECOMMENDED NEXT</div>
        <div class="mini-list" style="margin-top:8px">${[['Tire Rotation','Due in 328 mi'],['Brake Inspection','Due in 4,310 mi'],['Oil Change','Due in 328 mi']].map(r=>`<div class="row"><div class="m"><b style="font-size:13px">${r[0]}</b></div><a href="#/book" class="btn btn--amber btn--sm">Book</a></div>`).join('')}</div>
      </div></div>
    </div>`;
  }
  let chatActive=null;
  function chatThreads(){
    // one thread per order that has messages, for the current customer (c1) + demo 0582
    const nums=[...new Set(S().messages.map(m=>m.order))];
    return nums.map(num=>{const o=Store.order(num)||S().orders.find(x=>x.number===num);const msgs=Store.messagesFor(num);const last=msgs[msgs.length-1];return {num,o,last,unread:msgs.filter(m=>m.unread).length};});
  }
  function portalChat(params){
    const threads=chatThreads();
    chatActive = params.id && threads.find(t=>t.num===params.id) ? params.id : (chatActive||threads[0].num);
    const t=threads.find(x=>x.num===chatActive)||threads[0];
    // mark read
    Store.messagesFor(t.num).forEach(m=>m.unread=false);
    const adv=Store.tech((t.o&&t.o.technician)||'t1');
    const msgs=Store.messagesFor(t.num);
    setTimeout(()=>{const b=$('.chat__msgs');if(b)b.scrollTop=b.scrollHeight;},50);
    return `<div class="page-head"><div><div class="eyebrow">Messages</div><h1 style="margin-top:10px">LIVE CHAT</h1><p>Talk directly with your service advisor.</p></div></div>
    <div class="chat">
      <div class="chat__list">
        <div class="chat__list-h mono">CONVERSATIONS</div>
        ${threads.map(th=>{const a=Store.tech((th.o&&th.o.technician)||'t1');const preview=(th.last&&(th.last.photo?'Photo attachment':th.last.body)||'').slice(0,34);return `<button class="chat__thread ${th.num===chatActive?'sel':''}" onclick="Router.navigate('#/portal/chat?id=${th.num}')">${avatarEl(a,38)}<div class="chat__thread-b"><div class="chat__thread-top"><b>${a.name}</b>${th.last?`<span class="chat__thread-time mono">${window.fmtTime(th.last.created_date)}</span>`:''}</div><span class="chat__thread-prev">${preview}</span></div>${th.unread?`<span class="chat__unread">${th.unread}</span>`:''}</button>`;}).join('')}
      </div>
      <div class="chat__main">
        <div class="chat__head">${avatarEl(adv,40)}<div><b>${adv.name}</b><div class="mono faint"><span class="dot ok"></span>Online · ${adv.role}</div></div><span class="mono faint" style="margin-left:auto">Order ${t.num}</span></div>
        <div class="chat__msgs" id="chatMsgs">${msgs.map(m=>msgBubble(m,adv,Store.cust('c1'))).join('')}</div>
        <form class="chat__input" onsubmit="Pages.sendChat(event,'${t.num}')">
          <button type="button" class="chat__attach" onclick="Pages.chatPhoto('${t.num}')" title="Attach photo" aria-label="Attach photo">${svg('order',18).replace('M6 3h9l5 5v13H6zM15 3v5h5M9 13h7M9 17h7','M4 16l4-4 3 3 5-6 4 5M4 6h16v12H4zM8 9a1.5 1.5 0 1 0 0 .01')}</button>
          <input id="chatIn" placeholder="Type your message…" autocomplete="off"><button class="chat__send" type="submit" aria-label="Send">${svg('arrow',18)}</button>
        </form>
      </div>
      <div class="chat__side panel">
        <div class="panel__bar"><span>ORDER DETAILS</span></div>
        <div class="panel__body">
          <div class="mono faint" style="line-height:2;font-size:12px">Order: <b style="color:var(--text)">${t.num}</b><br>Service: <b style="color:var(--text)">${t.o?Store.svc(t.o.service).name:'—'}</b><br>Status: <span class="amber">${t.o?t.o.status:'—'}</span></div>
          <div class="tag" style="margin-top:18px">HELPFUL LINKS</div>
          <div class="chat__links">${[['order','Service process','#/portal/order'],['settings','Warranty info','#/about'],['reports','Payment options','#/financing']].map(l=>`<a href="${l[2]}" class="chat__link">${svg(l[0],15)} ${l[1]}</a>`).join('')}</div>
        </div>
      </div>
    </div>`;
  }
  function msgBubble(m,adv,cust){
    cust = cust||Store.cust('c1'); adv = adv||Store.tech('t1');
    const who = m.sender==='customer'?cust:adv;
    const av = who?avatarEl(who,30):'';
    return `<div class="msgrow ${m.sender}">${av}<div class="msg ${m.sender}">${m.body}${m.photo?`<img class="msg__photo" src="${asset(m.photo+'.jpg')}" alt="attachment" loading="lazy">`:''}<div class="t">${window.fmtTime(m.created_date)}${m.sender==='customer'?' ✓✓':''}</div></div></div>`;
  }

  /* ---------------- CRM ---------------- */
  function crmDash(){
    const orders=S().orders;
    const byStatus={'In Progress':0,'Inspection':0,'Pending':0,'Completed':0};
    orders.forEach(o=>byStatus[o.status]=(byStatus[o.status]||0)+1);
    const donut = donutSVG([['In Progress',byStatus['In Progress'],'#ff8a1e'],['Inspection',byStatus['Inspection'],'#7fa8ff'],['Pending',byStatus['Pending'],'#e6cf5c'],['Completed',byStatus['Completed'],'#54cf8b']]);
    return `<div class="page-head"><div><div class="eyebrow">Owner CRM</div><h1 style="margin-top:10px">DASHBOARD</h1></div><span class="mono faint">${window.fmtDate(new Date())}</span></div>
    <div class="stats">
      <div class="stat">${svg('order',20).replace('<svg','<svg class="stat__ic"')}<div class="stat__k">Total Orders</div><div class="stat__v">124</div><div class="stat__d">+12% this month</div>${spark([8,10,9,12,11,14,13,16],'#a3abb2')}</div>
      <div class="stat">${svg('wrench',20).replace('<svg','<svg class="stat__ic"')}<div class="stat__k">In Progress</div><div class="stat__v amber">38</div><div class="stat__d">+8% this month</div>${spark([30,28,33,31,36,34,35,38],'#ff8a1e')}</div>
      <div class="stat">${svg('check',20).replace('<svg','<svg class="stat__ic"')}<div class="stat__k">Completed</div><div class="stat__v">86</div><div class="stat__d">+15% this month</div>${spark([60,64,68,72,76,80,83,86],'#54cf8b')}</div>
      <div class="stat">${svg('reports',20).replace('<svg','<svg class="stat__ic"')}<div class="stat__k">Revenue</div><div class="stat__v">$28.4k</div><div class="stat__d">+18% this month</div>${spark([18,22,19,26,24,31,28,34],'#ffb454')}</div>
    </div>
    <div class="dash-grid">
      <div class="panel"><div class="panel__bar"><span>RECENT ORDERS</span><a href="#/crm/orders" class="live">View all →</a></div>
        <table class="tbl"><thead><tr><th>Order #</th><th>Customer</th><th>Service</th><th>Status</th><th>Date</th></tr></thead>
        <tbody>${orders.map(o=>`<tr onclick="Router.navigate('#/crm/order?id=${o.number}')" style="cursor:pointer"><td class="id">${o.number}</td><td><div class="cell-user">${avatarEl(Store.cust(o.customer),26)}<b style="color:var(--text)">${Store.cust(o.customer).name}</b></div></td><td>${Store.svc(o.service).name}</td><td><span class="pill ${o.status.toLowerCase().replace(' ','')}">${o.status}</span></td><td>${window.fmtDate(o.created_date)}</td></tr>`).join('')}</tbody></table></div>
      <div style="display:flex;flex-direction:column;gap:12px">
        <div class="panel"><div class="panel__bar"><span>ORDERS BY STATUS</span></div><div class="panel__body"><div class="donut-wrap"><div class="donut">${donut}<div class="donut__c"><b>${orders.length}</b><span>ACTIVE</span></div></div>
          <div class="legend">${[['In Progress',byStatus['In Progress'],'#ff8a1e'],['Inspection',byStatus['Inspection'],'#7fa8ff'],['Pending',byStatus['Pending'],'#e6cf5c'],['Completed',byStatus['Completed'],'#54cf8b']].map(l=>`<div class="legend__row"><span class="sw" style="background:${l[2]}"></span>${l[0]}<b>${l[1]}</b></div>`).join('')}</div></div></div>
        <div class="panel"><div class="panel__bar"><span>TODAY'S APPOINTMENTS</span><span>${orders.length}</span></div><div class="panel__body mini-list">
          ${orders.slice(0,4).map((o,i)=>`<div class="row" onclick="Router.navigate('#/crm/order?id=${o.number}')" style="cursor:pointer"><div class="t">${['9:00','10:30','1:00','3:30'][i]}</div>${avatarEl(Store.cust(o.customer),30)}<div class="m"><b style="font-size:13px">${Store.cust(o.customer).name}</b><span class="faint mono" style="font-size:10px">${Store.svc(o.service).name}</span></div><span class="pill ${o.status.toLowerCase().replace(' ','')}">${o.status.split(' ')[0]}</span></div>`).join('')}
        </div></div>
      </div></div>
    </div>`;
  }
  function spark(vals,color){
    const w=88,h=26,max=Math.max(...vals),min=Math.min(...vals),rng=(max-min)||1;
    const pts=vals.map((v,i)=>`${(i/(vals.length-1)*w).toFixed(1)},${(h-2-((v-min)/rng)*(h-6)).toFixed(1)}`);
    const line=pts.join(' ');
    const area=`0,${h} ${line} ${w},${h}`;
    return `<svg class="spark" viewBox="0 0 ${w} ${h}" preserveAspectRatio="none"><polygon points="${area}" fill="${color}" opacity="0.08"/><polyline points="${line}" fill="none" stroke="${color}" stroke-width="1.6" stroke-linejoin="round" stroke-linecap="round"/><circle cx="${w}" cy="${(h-2-((vals[vals.length-1]-min)/rng)*(h-6)).toFixed(1)}" r="2" fill="${color}"/></svg>`;
  }
  function donutSVG(data){
    const total=data.reduce((s,d)=>s+d[1],0)||1; const r=70,c=2*Math.PI*r; let off=0;
    const segs=data.map(d=>{const frac=d[1]/total;const dash=frac*c;const s=`<circle cx="85" cy="85" r="${r}" fill="none" stroke="${d[2]}" stroke-width="16" stroke-dasharray="${dash} ${c-dash}" stroke-dashoffset="${-off}"/>`;off+=dash;return s;}).join('');
    return `<svg width="170" height="170" viewBox="0 0 170 170"><circle cx="85" cy="85" r="${r}" fill="none" stroke="var(--s700)" stroke-width="16"/>${segs}</svg>`;
  }
  const om = { page:1, per:8, sort:'date', dir:-1, status:'', q:'', sel:new Set() };
  function omData(){
    let list=Store.allOrders().slice();
    if(om.status) list=list.filter(o=>o.status===om.status);
    if(om.q){const q=om.q.toLowerCase();list=list.filter(o=>(o.number+Store.cust(o.customer).name+Store.veh(o.vehicle).make+Store.veh(o.vehicle).model+Store.svc(o.service).name).toLowerCase().includes(q));}
    const key={date:o=>o.created_date,total:o=>o.estimate_total,customer:o=>Store.cust(o.customer).name,status:o=>o.status,number:o=>o.number}[om.sort];
    list.sort((a,b)=>{const x=key(a),y=key(b);return (x>y?1:x<y?-1:0)*om.dir;});
    return list;
  }
  function crmOrders(){
    const all=Store.allOrders();
    const counts={All:all.length}; ['Pending','Inspection','In Progress','Quality Check','Ready','Completed'].forEach(s=>counts[s]=all.filter(o=>o.status===s).length);
    const tabs=['All','Pending','Inspection','In Progress','Quality Check','Ready','Completed'];
    const data=omData(); const pages=Math.max(1,Math.ceil(data.length/om.per));
    om.page=Math.min(om.page,pages);
    const rows=data.slice((om.page-1)*om.per, om.page*om.per);
    const sortCol=(k,l)=>`<th class="sortable ${om.sort===k?'on':''}" onclick="Pages.omSort('${k}')">${l} ${om.sort===k?(om.dir>0?'▲':'▼'):''}</th>`;
    return `<div class="page-head"><div><div class="eyebrow">All orders</div><h1 style="margin-top:10px">ORDER MANAGEMENT</h1><p>${all.length} total orders</p></div>
      <div class="row gap2"><button class="btn btn--ghost btn--sm" onclick="toast('Exported '+${data.length}+' rows to CSV','auto')">Export CSV</button><button class="btn btn--amber btn--sm" onclick="Flows.booking()">${svg('plus',14)} New order</button></div></div>
    <div class="om-tabs">${tabs.map(t=>`<button class="om-tab ${om.status===(t==='All'?'':t)?'on':''}" onclick="Pages.omFilter('${t==='All'?'':t}')">${t} <b>${counts[t]||0}</b></button>`).join('')}</div>
    <div class="toolbar"><div class="search">${svg('reports',14)}<input id="omq" placeholder="Search orders, customers, vehicles…" value="${om.q}" oninput="Pages.omSearch(this.value)"></div>
      <select onchange="Pages.omPer(this.value)" title="Rows per page"><option ${om.per==8?'selected':''}>8</option><option ${om.per==15?'selected':''}>15</option><option ${om.per==25?'selected':''}>25</option></select></div>
    <div class="om-bulk ${om.sel.size?'show':''}" id="omBulk"><span><b>${om.sel.size}</b> selected</span><div class="row gap2"><button class="btn btn--ghost btn--sm" onclick="Pages.omBulk('progress')">Mark In Progress</button><button class="btn btn--ghost btn--sm" onclick="Pages.omBulk('ready')">Mark Ready</button><button class="btn btn--ghost btn--sm" onclick="Pages.omClearSel()">Clear</button></div></div>
    <div class="panel"><table class="tbl" id="ordTbl"><thead><tr>
      <th style="width:34px"><input type="checkbox" id="omAll" onchange="Pages.omSelAll(this.checked)"></th>
      ${sortCol('number','Order #')}${sortCol('customer','Customer')}<th>Vehicle</th><th>Service</th><th>Tech</th>${sortCol('status','Status')}${sortCol('total','Total')}${sortCol('date','Date')}</tr></thead>
      <tbody>${rows.map(o=>ordRow(o)).join('')||'<tr><td colspan="9" style="text-align:center;padding:30px" class="dim">No orders match.</td></tr>'}</tbody></table>
      <div class="om-foot"><span class="mono faint">Showing ${(om.page-1)*om.per+1}–${Math.min(om.page*om.per,data.length)} of ${data.length}</span>
        <div class="pager">${pagerBtns(om.page,pages)}</div></div></div>`;
  }
  function pagerBtns(p,pages){
    let out=`<button class="pg" ${p<=1?'disabled':''} onclick="Pages.omPage(${p-1})">‹</button>`;
    const nums=new Set([1,pages,p,p-1,p+1]); let prev=0;
    [...nums].filter(n=>n>=1&&n<=pages).sort((a,b)=>a-b).forEach(n=>{if(prev&&n-prev>1)out+='<span class="pg-gap">…</span>';out+=`<button class="pg ${n===p?'on':''}" onclick="Pages.omPage(${n})">${n}</button>`;prev=n;});
    out+=`<button class="pg" ${p>=pages?'disabled':''} onclick="Pages.omPage(${p+1})">›</button>`; return out;
  }
  function ordRow(o){const v=Store.veh(o.vehicle);return `<tr data-status="${o.status}" style="cursor:pointer" onclick="if(event.target.closest('.pill,input'))return;Router.navigate('#/crm/order?id=${o.number}')">
    <td><input type="checkbox" ${om.sel.has(o.number)?'checked':''} onclick="event.stopPropagation();Pages.omSel('${o.number}',this.checked)"></td>
    <td class="id">${o.number}</td><td><div class="cell-user">${avatarEl(Store.cust(o.customer),28)}<b style="color:var(--text)">${Store.cust(o.customer).name}</b></div></td><td>${v.year} ${v.make} ${v.model}</td><td>${Store.svc(o.service).name}</td><td>${Store.tech(o.technician).name}</td>
    <td><button class="pill ${o.status.toLowerCase().replace(/ /g,'')}" onclick="event.stopPropagation();Pages.cycleStatus('${o.number}')">${o.status}</button></td>
    <td>${window.fmtMoney(o.estimate_total)}</td><td>${window.fmtDate(o.created_date)}</td></tr>`;}
  function crmTasks(){
    const cols=['Pending','In Progress','Completed'];
    return `<div class="page-head"><div><div class="eyebrow">Workflow</div><h1 style="margin-top:10px">TASKS</h1><p>Drag cards between columns — moves fire status automations.</p></div></div>
    <div class="kanban">${cols.map(col=>`<div class="kcol" data-col="${col}"><div class="kcol__head">${col}<span class="cnt">${S().tasks.filter(t=>t.column===col).length}</span></div><div class="kcol__body" data-col="${col}">${S().tasks.filter(t=>t.column===col).map(kcard).join('')}</div></div>`).join('')}</div>`;
  }
  function kcard(t){return `<div class="kcard" draggable="true" data-id="${t.id}"><div class="kcard__id">${t.order}</div><div class="kcard__t">${t.title}</div><div class="kcard__f"><span>${Store.tech(t.assignee).name}</span><span>${window.fmtDate(t.due)}</span></div></div>`;}
  function crmOrderDetail(params){
    const num = params.id || S().orders[0].number;
    const o = Store.order(num) || S().orders[0];
    const v=Store.veh(o.vehicle), c=Store.cust(o.customer), sv=Store.svc(o.service), tch=Store.tech(o.technician);
    const steps=['Received','Inspection','In Progress','Quality Check','Ready'];
    const statuses=['Pending','Inspection','In Progress','Quality Check','Ready','Completed'];
    const updates=Store.updatesFor(o.number);
    return `<div class="page-head"><div><a href="#/crm/orders" class="mono faint" style="display:inline-flex;gap:6px;align-items:center;margin-bottom:8px">${svg('back',14)} All orders</a><h1>${o.number}</h1><p>${c.name} · ${v.year} ${v.make} ${v.model} · ${sv.name}</p></div>
      <div class="row gap3"><a href="#/portal/chat" class="btn btn--ghost btn--sm">${svg('chat',15)} Chat</a><button class="btn btn--amber btn--sm" onclick="Pages.printInvoice('${o.number}')">Invoice</button></div></div>
    <div class="dash-grid">
      <div style="display:flex;flex-direction:column;gap:12px">
        <div class="panel"><div class="panel__bar"><span>STATUS CONTROL</span><span class="live"><span class="dot amber pulse"></span>${o.progress}%</span></div>
          <div class="panel__body">
            <div class="tracker">${steps.map((st,i)=>`<div class="tstep ${i<o.stage-1?'done':''} ${i===o.stage-1?'active':''}"><div class="tnode">${i<o.stage-1?svg('check',15):i+1}</div><div class="tlab">${st}</div></div>`).join('')}</div>
            <div class="row gap3" style="margin-top:18px;flex-wrap:wrap">
              <div class="field" style="margin:0;flex:1;min-width:180px"><label>Set status (fires A3)</label>
                <select id="ostat" onchange="Pages.changeStatus('${o.number}',this.value)">${statuses.map(s=>`<option ${s===o.status?'selected':''}>${s}</option>`).join('')}</select></div>
              <button class="btn btn--ghost btn--sm" style="align-self:flex-end" onclick="Pages.assignTech('${o.number}')">Reassign tech</button>
            </div>
          </div></div>
        <div class="panel"><div class="panel__bar"><span>BAY UPDATES · TIMELINE</span></div>
          <div class="panel__body">
            <form onsubmit="Pages.postUpdate(event,'${o.number}')" class="row gap2" style="margin-bottom:14px">
              <input id="upd" class="" placeholder="Post an update to the customer…" style="flex:1;background:var(--s900);border:1px solid var(--line);border-radius:var(--r1);padding:10px 12px;color:var(--text)">
              <button class="btn btn--amber btn--sm" type="submit">Post</button></form>
            <div class="timeline">${updates.map(u=>`<div class="tl-item"><div class="tl-time">${window.fmtDate(u.created_date)} · ${window.fmtTime(u.created_date)}</div><div class="tl-msg">${u.message}</div></div>`).join('')||'<p class="dim">No updates yet — post the first one.</p>'}</div>
          </div></div>
      </div>
      <div style="display:flex;flex-direction:column;gap:12px">
        <div class="panel"><div class="panel__bar"><span>CUSTOMER</span></div><div class="panel__body"><b class="disp" style="font-size:18px">${c.name}</b><div class="mono faint" style="margin-top:8px;line-height:1.9">${c.phone}<br>${c.email}</div><a href="tel:${c.phone}" class="btn btn--ghost btn--sm" style="margin-top:12px">${svg('phone',14)} Call</a></div></div>
        <div class="panel"><div class="panel__bar"><span>VEHICLE</span></div><div class="panel__body"><b class="disp" style="font-size:16px">${v.year} ${v.make} ${v.model}</b><div class="mono faint" style="margin-top:8px;line-height:1.9">Plate: ${v.plate}<br>VIN: ${v.vin||'—'}<br>${(v.mileage||0).toLocaleString()} mi</div></div></div>
        <div class="panel"><div class="panel__bar"><span>ESTIMATE</span></div><div class="panel__body">
          <div class="between mono" style="padding:6px 0"><span class="faint">Labor</span><b>${window.fmtMoney(o.estimate_labor)}</b></div>
          <div class="between mono" style="padding:6px 0"><span class="faint">Parts</span><b>${o.estimate_parts?window.fmtMoney(o.estimate_parts):'Included'}</b></div>
          <div class="between mono" style="padding:10px 0;border-top:1px solid var(--line);margin-top:6px"><span>Total</span><b class="amber disp" style="font-size:22px">${window.fmtMoney(o.estimate_total)}</b></div>
          <div class="row gap2" style="margin-top:12px"><span class="badge ${o.status==='Ready'||o.status==='Completed'?'ok':'warn'}">${o.status}</span><span class="badge ghost">${tch.name}</span></div>
        </div></div>
      </div>
    </div>`;
  }

  function crmCalendar(){
    const days=['MON','TUE','WED','THU','FRI','SAT'];
    const dates=['12','13','14','15','16','17'];
    const bays=['Bay 01','Bay 02','Bay 03','Lift'];
    const orders=S().orders;
    // build a simple appointment grid: place orders across days/bays
    const appts={};
    orders.forEach((o,i)=>{ const day=i%6, bay=i%4; (appts[day+'-'+bay]=appts[day+'-'+bay]||[]).push(o); });
    return `<div class="page-head"><div><div class="eyebrow">This week · May</div><h1 style="margin-top:10px">CALENDAR</h1><p>Bay schedule — drag to reschedule on the live build.</p></div>
      <div class="row gap2"><button class="btn btn--ghost btn--sm">${svg('back',14)}</button><span class="badge ghost">Week of May 12</span><button class="btn btn--ghost btn--sm" style="transform:scaleX(-1)">${svg('back',14)}</button></div></div>
    <div class="cal">
      <div class="cal__head"><div class="cal__corner mono faint">BAY</div>${days.map((d,i)=>`<div class="cal__day"><b>${d}</b><span>${dates[i]}</span></div>`).join('')}</div>
      ${bays.map((bay,bi)=>`<div class="cal__row"><div class="cal__bay">${bay}</div>${days.map((_,di)=>`<div class="cal__cell">${(appts[di+'-'+bi]||[]).map(o=>`<div class="cal__appt ${o.status.toLowerCase().replace(' ','')}" onclick="Router.navigate('#/crm/order?id=${o.number}')"><b>${Store.svc(o.service).name}</b><span>${Store.cust(o.customer).name}</span></div>`).join('')}</div>`).join('')}</div>`).join('')}
    </div>`;
  }

  function crmDispatch(){
    const tows=S().tows||[];
    const active=tows.filter(t=>t.status!=='Closed');
    return `<div class="page-head"><div><div class="eyebrow">Emergency ops</div><h1 style="margin-top:10px">TOW DISPATCH</h1><p>Live tow requests with GPS. Each new request fires <b class="amber">A2</b>.</p></div><button class="btn btn--amber btn--sm" onclick="Flows.tow()">${svg('tow',15)} New request</button></div>
    <div class="stats" style="grid-template-columns:repeat(3,1fr)">
      <div class="stat"><div class="stat__k">Active Requests</div><div class="stat__v amber">${active.length}</div><div class="stat__d">live now</div></div>
      <div class="stat"><div class="stat__k">Avg ETA</div><div class="stat__v">${Math.round(active.reduce((s,t)=>s+(t.eta||0),0)/(active.length||1))} min</div><div class="stat__d">to arrival</div></div>
      <div class="stat"><div class="stat__k">Driver Units</div><div class="stat__v">2 / 3</div><div class="stat__d">on the road</div></div>
    </div>
    <div class="panel"><div class="panel__bar"><span>DISPATCH BOARD</span><span class="live"><span class="dot amber pulse"></span>MONITORING</span></div>
      <table class="tbl"><thead><tr><th>Ref</th><th>Vehicle</th><th>Problem</th><th>GPS</th><th>ETA</th><th>Status</th><th></th></tr></thead>
      <tbody>${tows.map(t=>`<tr><td class="id">${t.ref}</td><td style="color:var(--text)">${t.vehicle_type}</td><td>${t.problem}</td><td class="mono">${t.lat}, ${t.lng}</td><td>${t.eta?t.eta+' min':'—'}</td><td><span class="pill ${t.status==='Arrived'?'completed':t.status==='Dispatched'?'progress':'pending'}">${t.status}</span></td><td><a class="btn btn--ghost btn--sm" href="https://maps.google.com/?q=${t.lat},${t.lng}" target="_blank" rel="noopener">Map</a></td></tr>`).join('')}</tbody></table></div>`;
  }

  function crmReports(){
    const rev=[18,22,19,26,24,31,28]; const max=Math.max(...rev);
    const days=['Mon','Tue','Wed','Thu','Fri','Sat','Sun'];
    const svcMix=[['Brakes',28,'#ff8a1e'],['Engine',21,'#7fa8ff'],['Body & Paint',18,'#e6cf5c'],['Maintenance',22,'#54cf8b'],['Other',11,'#a3abb2']];
    return `<div class="page-head"><div><div class="eyebrow">Performance</div><h1 style="margin-top:10px">REPORTS</h1><p>Revenue, throughput and service mix.</p></div><select class="chip"><option>This week</option><option>This month</option><option>This quarter</option></select></div>
    <div class="stats">
      <div class="stat"><div class="stat__k">Revenue (wk)</div><div class="stat__v">$28.4k</div><div class="stat__d">+18%</div></div>
      <div class="stat"><div class="stat__k">Avg Ticket</div><div class="stat__v">$342</div><div class="stat__d">+6%</div></div>
      <div class="stat"><div class="stat__k">Cars / day</div><div class="stat__v">11</div><div class="stat__d">+2</div></div>
      <div class="stat"><div class="stat__k">Bay Utilization</div><div class="stat__v amber">78%</div><div class="stat__d">+4%</div></div>
    </div>
    <div class="dash-grid">
      <div class="panel"><div class="panel__bar"><span>REVENUE · LAST 7 DAYS</span><span>$28,450</span></div><div class="panel__body">
        <div class="bars">${rev.map((v,i)=>`<div class="bars__col"><div class="bars__bar" style="--h:${Math.round(v/max*100)}%" title="$${v}k"></div><span>${days[i]}</span></div>`).join('')}</div>
      </div></div>
      <div class="panel"><div class="panel__bar"><span>SERVICE MIX</span></div><div class="panel__body">
        ${svcMix.map(m=>`<div style="margin-bottom:12px"><div class="between mono" style="font-size:11px;margin-bottom:5px"><span>${m[0]}</span><b>${m[1]}%</b></div><div class="meter"><i style="width:${m[1]}%;background:${m[2]}"></i></div></div>`).join('')}
      </div></div>
    </div>`;
  }

  function avatarEl(c,size){size=size||30;const initials=(c.name||'?').split(' ').map(w=>w[0]).slice(0,2).join('');
    return c&&c.avatar?`<span class="avatar" style="width:${size}px;height:${size}px"><img src="${asset(c.avatar+'.jpg')}" alt=""></span>`:`<span class="avatar avatar--i" style="width:${size}px;height:${size}px">${initials}</span>`;}
  function crmCustomers(){
    return `<div class="page-head"><div><div class="eyebrow">Directory</div><h1 style="margin-top:10px">CUSTOMERS</h1><p>${S().customers.length} customers on file</p></div><button class="btn btn--amber btn--sm" onclick="toast('Add customer — form on live build')">${svg('plus',14)} Add customer</button></div>
    <div class="panel"><table class="tbl"><thead><tr><th>Customer</th><th>Phone</th><th>Email</th><th>Vehicles</th><th>Last visit</th></tr></thead>
      <tbody>${S().customers.map(c=>{const nv=S().vehicles.filter(v=>v.customer===c.id).length;return `<tr style="cursor:pointer"><td><div class="cell-user">${avatarEl(c,34)}<div><b style="color:var(--text)">${c.name}</b><span class="faint mono" style="font-size:10px">${c.id.toUpperCase()}</span></div></div></td><td>${c.phone}</td><td>${c.email}</td><td>${nv}</td><td class="mono faint">May 2024</td></tr>`;}).join('')}</tbody></table></div>`;
  }

  /* ---- interactions ---- */
  const api = { home,services,serviceDetail,about,reviews,gallery,contact,specials,financing,warranty,faq,book,uikit,
    portalHome,portalOrder,portalGarage,portalHistory,portalChat,crmDash,crmOrders,crmOrderDetail,crmTasks,crmCalendar,crmDispatch,crmReports,crmCustomers };

  api._after = (path)=>{
    if(path==='/crm/tasks') Pages.initKanban();
    if(path==='/financing') Pages.calc();
    if(path==='/service'){ Pages.initCompare(); Pages.initSvcStage(); }
    if(path==='/'||path==='/services') Pages.initServiceIcons();
  };
  api.initServiceIcons = ()=>{
    if(!window.gsap) return;
    if(matchMedia('(prefers-reduced-motion:reduce)').matches) return;  // respect a11y
    $$('.svc-tile').forEach(tile=>{
      if(tile._gsap) return; tile._gsap=1;
      const img=tile.querySelector('.svc-tile__ic img');
      if(!img) return;
      tile.addEventListener('pointerenter',()=>{
        gsap.to(img,{scale:1.14,y:-3,rotate:-5,duration:.5,ease:'back.out(2.4)'});
      });
      tile.addEventListener('pointerleave',()=>{
        gsap.to(img,{scale:1,y:0,rotate:0,duration:.45,ease:'power2.out'});
      });
    });
  };
  api.initSvcStage = ()=>{
    const stage=$('[data-svc-stage]'); if(!stage||stage._wired) return; stage._wired=1;
    const reduce=matchMedia('(prefers-reduced-motion:reduce)').matches;
    // entrance "reveal": scene settles + plate flies in + flash pulse
    requestAnimationFrame(()=>{ stage.classList.add('in'); });
    setTimeout(()=>{ stage.classList.add('in'); }, 120); // fallback so it never stays hidden
    if(!reduce){
      const flash=stage.querySelector('[data-flash]');
      setTimeout(()=>{ if(flash){flash.classList.add('on'); setTimeout(()=>flash.classList.remove('on'),520);} }, 520);
    }
    // animate meter fills + scan ring from 0 → target for a "live" feel
    if(!reduce){
      $$('.svc-meter__fill',stage).forEach(f=>{ const w=f.style.width; f.style.width='0%'; requestAnimationFrame(()=>setTimeout(()=>{f.style.width=w;},260)); });
      $$('.svc-scan__ring',stage).forEach(r=>{ const p=r.style.getPropertyValue('--p'); r.style.setProperty('--p','0'); setTimeout(()=>r.style.setProperty('--p',p),300); });
    }
  };
  api.initCompare = ()=>{ $$('[data-stage="compare"]').forEach(box=>{
    if(box._wired) return; box._wired=1; box.style.setProperty('--split','52%');
    let drag=false; const set=x=>{const r=box.getBoundingClientRect();let p=((x-r.left)/r.width)*100;p=Math.max(2,Math.min(98,p));box.style.setProperty('--split',p+'%');};
    const xy=e=>(e.touches?e.touches[0]:e).clientX;
    box.addEventListener('pointerdown',e=>{drag=true;set(xy(e));});
    addEventListener('pointermove',e=>{if(drag)set(xy(e));}); addEventListener('pointerup',()=>drag=false);
    const h=box.querySelector('.compare__handle'); if(h)h.addEventListener('keydown',e=>{const c=parseFloat(getComputedStyle(box).getPropertyValue('--split'))||52;if(e.key==='ArrowLeft')box.style.setProperty('--split',Math.max(2,c-4)+'%');if(e.key==='ArrowRight')box.style.setProperty('--split',Math.min(98,c+4)+'%');});
  }); };
  api.calc = ()=>{const amt=+($('#amt')?.value||1000);const term=+($('#term')?.value||12);$('#amtV').textContent=window.fmtMoney(amt);$('#pay').innerHTML=window.fmtMoney(Math.round(amt/term*1.08))+'<span style="font-size:16px;color:var(--faint)">/mo</span>';};
  api.applyFinancing=()=>{Store.createLead('Financing',{amount:$('#amt').value,term:$('#term').value});toast('Application sent — we\'ll call you','auto');};
  api.claimSpecial=(s)=>{Store.createLead('Specials',{offer:s});toast('Offer claimed — check your phone','auto');};
  api.submitContact=(e)=>{e.preventDefault();const f=e.target;Store.createLead('Contact',{name:f.name.value,phone:f.phone.value,message:f.message.value});f.reset();toast('Message sent','auto');};
  api.submitBook=(e)=>{e.preventDefault();const f=e.target;const sv=Store.svc(f.service.value);Store.createLead('Booking',{service:sv?sv.name:f.service.value,date:f.date.value,time:f.time.value,vehicle:f.vehicle.value,phone:f.phone.value});window.dispatchEvent(new CustomEvent('automation',{detail:{name:'A1 · Booking confirmed + shop alert',detail:{service:sv?sv.name:''},at:new Date().toISOString()}}));toast("Appointment requested — we'll call to confirm",'auto');f.reset();};
  api.writeReview=()=>{Store.createLead('Review',{});toast('Thanks! Review link sent','auto');};
  api.garagePick=(id)=>{garageSel=id;const vs=S().vehicles.filter(v=>v.customer==='c1');$$('.veh-list .veh-card').forEach((c,i)=>c.classList.toggle('sel',vs[i].id===id));const det=$('#garageDetail');if(det)det.innerHTML=garageDetail(vs.find(v=>v.id===id));};
  api.remindMe=(id)=>{const v=S().vehicles.find(x=>x.id===id);Store.createLead('Reminder',{vehicle:`${v.year} ${v.make} ${v.model}`,note:'auto maintenance reminders on'});window.dispatchEvent(new CustomEvent('automation',{detail:{name:'A7 · Service reminders scheduled',detail:{vehicle:`${v.make} ${v.model}`},at:new Date().toISOString()}}));toast('Reminders on — we\'ll text you when service is due','auto');};
  api.chatPhoto=(num)=>{const photo=['svc-dent','svc-brakes','svc-diagnostics'][Math.floor(Math.random()*3)];Store.sendMessage(num,'customer','John Smith','Photo of the issue:');const arr=Store.messagesFor(num);arr[arr.length-1].photo=photo;const b=$('#chatMsgs');b.insertAdjacentHTML('beforeend',msgBubble({sender:'customer',sender_name:'John Smith',body:'Photo of the issue:',photo,created_date:new Date().toISOString()}));b.scrollTop=b.scrollHeight;toast('Photo sent to advisor');};
  api.sendChat=(e,num)=>{e.preventDefault();const i=$('#chatIn');if(!i.value.trim())return;Store.sendMessage(num,'customer','John Smith',i.value);const b=$('#chatMsgs');b.insertAdjacentHTML('beforeend',msgBubble({sender:'customer',sender_name:'John Smith',body:i.value,created_date:new Date().toISOString()}));i.value='';b.scrollTop=b.scrollHeight;
    setTimeout(()=>{Store.sendMessage(num,'staff','Mike Johnson','Got it — I\'ll take care of that and update you shortly.');b.insertAdjacentHTML('beforeend',msgBubble({sender:'staff',sender_name:'Mike Johnson',body:'Got it — I\'ll take care of that and update you shortly.',created_date:new Date().toISOString()}));b.scrollTop=b.scrollHeight;},1400);};
  api.simUpdate=(num)=>{Store.addUpdate(num,'Parts installed — moving to quality check.');Router.render();};
  api.approve=(num,decision)=>{Store.approveEstimate(num,decision);toast(decision==='approved'?'Work authorized — thank you!':'Estimate declined','auto');Router.render();};
  api.cycleStatus=(num)=>{const seq=['Pending','Inspection','In Progress','Quality Check','Ready','Completed'];const o=Store.order(num);const ni=(seq.indexOf(o.status)+1)%seq.length;Store.setOrderStatus(num,seq[ni]);Router.render();};
  api.changeStatus=(num,s)=>{Store.setOrderStatus(num,s);Router.render();};
  api.postUpdate=(e,num)=>{e.preventDefault();const i=$('#upd');if(!i.value.trim())return;Store.addUpdate(num,i.value.trim());Router.render();};
  api.assignTech=(num)=>{const o=Store.order(num);const techs=Store.db.technicians;const ni=(techs.findIndex(t=>t.id===o.technician)+1)%techs.length;o.technician=techs[ni].id;toast('Reassigned to '+techs[ni].name);Router.render();};
  api.printInvoice=(num)=>{toast('Invoice generated for '+num,'auto');};
  api.omSort=(k)=>{if(om.sort===k)om.dir*=-1;else{om.sort=k;om.dir=k==='date'?-1:1;}Router.render();};
  api.omFilter=(s)=>{om.status=s;om.page=1;Router.render();};
  api.omPer=(n)=>{om.per=+n;om.page=1;Router.render();};
  api.omPage=(n)=>{om.page=n;Router.render();};
  api.omSearch=(v)=>{om.q=v;om.page=1;const data=omData();Router.render();setTimeout(()=>{const i=$('#omq');if(i){i.focus();i.setSelectionRange(i.value.length,i.value.length);}},0);};
  api.omSel=(num,on)=>{on?om.sel.add(num):om.sel.delete(num);$('#omBulk').classList.toggle('show',om.sel.size);$('#omBulk').querySelector('b').textContent=om.sel.size;};
  api.omSelAll=(on)=>{const data=omData().slice((om.page-1)*om.per,om.page*om.per);data.forEach(o=>on?om.sel.add(o.number):om.sel.delete(o.number));Router.render();};
  api.omClearSel=()=>{om.sel.clear();Router.render();};
  api.omBulk=(kind)=>{const status=kind==='ready'?'Ready':'In Progress';om.sel.forEach(num=>{const o=Store.order(num)||Store.allOrders().find(x=>x.number===num);if(o){o.status=status;}});toast(om.sel.size+' orders → '+status+' · A3 fired for each','auto');window.dispatchEvent(new CustomEvent('automation',{detail:{name:'A3 · Bulk status update → customers notified',detail:{count:om.sel.size,status},at:new Date().toISOString()}}));om.sel.clear();Router.render();};
  api.initKanban=()=>{
    let dragged=null;
    $$('.kcard').forEach(c=>{c.addEventListener('dragstart',()=>{dragged=c;c.classList.add('drag');});c.addEventListener('dragend',()=>{c.classList.remove('drag');});});
    $$('.kcol__body').forEach(col=>{
      col.addEventListener('dragover',e=>{e.preventDefault();col.parentElement.classList.add('dragover');});
      col.addEventListener('dragleave',()=>col.parentElement.classList.remove('dragover'));
      col.addEventListener('drop',e=>{e.preventDefault();col.parentElement.classList.remove('dragover');if(dragged){col.appendChild(dragged);Store.moveTask(dragged.dataset.id,col.dataset.col);updateKcounts();toast('Task moved → '+col.dataset.col);}});
    });
    function updateKcounts(){$$('.kcol').forEach(k=>{k.querySelector('.cnt').textContent=k.querySelector('.kcol__body').children.length;});}
  };
  return api;
})();
