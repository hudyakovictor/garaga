/* ============================================================
   STORE — in-memory data layer (stands in for Base44 entities).
   Mutations log the automation that would fire in Base44, so the
   prototype demonstrates the automation wiring end-to-end.
   ============================================================ */
const Store = (() => {
  const db = JSON.parse(JSON.stringify(window.SEED));
  const listeners = new Set();
  const emit = () => listeners.forEach(fn => fn());

  // resolve helpers (relations)
  const svc = k => db.services.find(s => s.key === k) || {};
  const cust = id => db.customers.find(c => c.id === id) || {};
  const veh = id => db.vehicles.find(v => v.id === id) || {};
  const tech = id => db.technicians.find(t => t.id === id) || {};
  const order = num => db.orders.find(o => o.number === num);

  // "automation bus" — records what Base44 would trigger (see docs 02)
  const automations = [];
  function fire(name, detail){
    const rec = { name, detail, at: new Date().toISOString() };
    automations.unshift(rec);
    console.info('%c⚡ AUTOMATION','color:#ff8a1e;font-weight:bold', name, detail);
    window.dispatchEvent(new CustomEvent('automation', { detail: rec }));
    return rec;
  }

  return {
    db, svc, cust, veh, tech, order, automations,
    on(fn){ listeners.add(fn); return () => listeners.delete(fn); },

    // ---- mutations (each mirrors a Base44 create/update + its automation) ----
    createBooking(data){
      const rec = { id:'b'+Date.now(), status:'New', created_date:new Date().toISOString(), ...data };
      db.bookings = db.bookings || []; db.bookings.push(rec);
      fire('A1 · Booking → confirmation + shop alert', { service:data.service, when:data.date+' '+data.slot, contact:data.contact });
      emit(); return rec;
    },
    createTow(data){
      const ref = 'TOW-'+Math.random().toString(36).slice(2,7).toUpperCase();
      const rec = { id:'tow'+Date.now(), status:'Dispatched', ref, created_date:new Date().toISOString(), ...data };
      db.tows = db.tows || []; db.tows.push(rec);
      fire('A2 · Tow request → driver dispatch (SMS + GPS)', { ref, coords:data.lat+','+data.lng, vehicle:data.vehicle_type });
      emit(); return rec;
    },
    setOrderStatus(num, status){
      const o = order(num); if(!o) return;
      o.status = status;
      o.progress = { 'Pending':5,'Inspection':30,'In Progress':60,'Quality Check':85,'Ready':95,'Completed':100 }[status] ?? o.progress;
      o.stage = { 'Pending':1,'Inspection':2,'In Progress':3,'Quality Check':4,'Ready':5,'Completed':5 }[status] ?? o.stage;
      fire('A3 · Order status → customer SMS/email', { order:num, status, progress:o.progress });
      if(status==='Ready') fire('A6 · Ready for pickup → SMS + review link', { order:num });
      emit();
    },
    addUpdate(num, message){
      const rec = { order:num, message, created_date:new Date().toISOString() };
      db.orderUpdates.push(rec);
      fire('A4 · New bay update → notify customer', { order:num, message });
      emit(); return rec;
    },
    sendMessage(num, sender, name, body){
      const rec = { order:num, sender, sender_name:name, body, created_date:new Date().toISOString() };
      db.messages.push(rec);
      if(sender==='staff') fire('A5 · Staff reply → notify customer', { order:num });
      emit(); return rec;
    },
    moveTask(id, column){
      const t = db.tasks.find(x=>x.id===id); if(t){ t.column = column; emit(); }
    },
    createLead(kind, data){
      const rec = { id:'l'+Date.now(), kind, created_date:new Date().toISOString(), ...data };
      db.leads = db.leads || []; db.leads.push(rec);
      fire('A9 · Lead ('+kind+') → shop alert + auto-reply', data);
      emit(); return rec;
    },
    approveEstimate(num, decision){
      const o = order(num); if(!o) return;
      o.approval = decision;
      if(decision==='approved'){ o.status='In Progress'; o.stage=3; o.progress=Math.max(o.progress,60);
        fire('A11 · Estimate approved → work authorized + tech notified', { order:num, total:o.estimate_total }); }
      else fire('A12 · Estimate declined → advisor follow-up', { order:num });
      emit();
    },
    messagesFor(num){ return db.messages.filter(m=>m.order===num); },
    updatesFor(num){ return db.orderUpdates.filter(u=>u.order===num); },

    // Expanded order list for the CRM table (real seed + generated) so
    // pagination/sorting are meaningful. On Base44 this is just Order records.
    allOrders(){
      if (db._all) return db._all;
      const svcKeys=db.services.map(s=>s.key);
      const statuses=['Pending','Inspection','In Progress','Quality Check','Ready','Completed'];
      const gen=[];
      let n=6570;
      for(let i=0;i<118;i++){
        const c=db.customers[i%db.customers.length];
        const v=db.vehicles[i%db.vehicles.length];
        const t=db.technicians[i%db.technicians.length];
        const st=statuses[Math.floor((Math.sin(i*3.1)+1)/2*statuses.length)%statuses.length];
        const day=String((i%27)+1).padStart(2,'0');
        gen.push({number:'NCAR-2024-'+String(n-i).padStart(4,'0'),customer:c.id,vehicle:v.id,
          service:svcKeys[i%svcKeys.length],technician:t.id,status:st,
          estimate_total:60+((i*137)%1900),created_date:'2024-04-'+day, generated:true});
      }
      db._all=[...db.orders, ...gen];
      return db._all;
    },
  };
})();
window.Store = Store;
