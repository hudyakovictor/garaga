/* ============================================================
   UI HELPERS — icons, format, toast, modal, automation console
   ============================================================ */
const $ = (s,c=document)=>c.querySelector(s);
const $$ = (s,c=document)=>[...c.querySelectorAll(s)];
const el = (tag,cls,html)=>{const e=document.createElement(tag);if(cls)e.className=cls;if(html!=null)e.innerHTML=html;return e;};
// asset resolver — returns inlined data-URI in the bundled build, else file path
window.asset = f => (window.__ASSETS && window.__ASSETS[f]) || ('assets/'+f);

// clean lucide-style icon set (24x24, stroke) — reads well at 16-22px
const ICONS = {
  dash:'M3 13h8V3H3zM13 21h8V11h-8zM13 3v6h8V3zM3 21h8v-6H3z',
  order:'M14 3H8a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h8a2 2 0 0 0 2-2V7zM14 3v4h4M9 13h6M9 17h4',
  car:'M5 11l1.5-4.3A2 2 0 0 1 8.4 5.3h7.2a2 2 0 0 1 1.9 1.4L19 11M5 11h14a1 1 0 0 1 1 1v4a1 1 0 0 1-1 1h-1v1.5a1 1 0 0 1-1 1h-1a1 1 0 0 1-1-1V17H9v1.5a1 1 0 0 1-1 1H7a1 1 0 0 1-1-1V17H5a1 1 0 0 1-1-1v-4a1 1 0 0 1 1-1zM7.5 14h.01M16.5 14h.01',
  history:'M3 12a9 9 0 1 0 9-9 9 9 0 0 0-6.4 2.6L3 8M3 4v4h4M12 8v4l3 2',
  chat:'M21 11.5a8.4 8.4 0 0 1-9 8.4 9 9 0 0 1-3.8-.8L3 21l1.9-5.2A8.4 8.4 0 0 1 12 3.1a8.4 8.4 0 0 1 9 8.4z',
  tasks:'M9 6h11M9 12h11M9 18h11M4.5 6l1 1 2-2M4.5 12l1 1 2-2M4.5 18l1 1 2-2',
  users:'M17 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2M9.5 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8M22 21v-2a4 4 0 0 0-3-3.9M16 3.1a4 4 0 0 1 0 7.8',
  calendar:'M6 3v3M18 3v3M4 8h16M5 6h14a1 1 0 0 1 1 1v12a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V7a1 1 0 0 1 1-1z',
  inventory:'M21 8v10a1 1 0 0 1-.5.9l-8 4a1 1 0 0 1-1 0l-8-4A1 1 0 0 1 3 18V8m0 0l9 4.5L21 8M3 8l9-4 9 4',
  reports:'M4 20V4M4 20h16M8 16v-4M12 16V8M16 16v-6',
  settings:'M12 15a3 3 0 1 0 0-6 3 3 0 0 0 0 6zM19.4 15a1.6 1.6 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.6 1.6 0 0 0-2.7 1.1V21a2 2 0 1 1-4 0v-.1a1.6 1.6 0 0 0-2.7-1.1l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1A1.6 1.6 0 0 0 4.6 15H4.5a2 2 0 1 1 0-4h.1a1.6 1.6 0 0 0 1.1-2.7l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.6 1.6 0 0 0 2.7-1.1V4.5a2 2 0 1 1 4 0v.1a1.6 1.6 0 0 0 2.7 1.1l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.6 1.6 0 0 0-1.1 2.7v.1a2 2 0 1 1 0 4h-.1a1.6 1.6 0 0 0-1.5 1z',
  check:'M20 6L9 17l-5-5',
  arrow:'M5 12h14M13 6l6 6-6 6',
  back:'M19 12H5M11 6l-6 6 6 6',
  phone:'M22 16.9v3a2 2 0 0 1-2.2 2 19.8 19.8 0 0 1-8.6-3.1 19.5 19.5 0 0 1-6-6 19.8 19.8 0 0 1-3.1-8.7A2 2 0 0 1 4.1 2h3a2 2 0 0 1 2 1.7c.1 1 .4 1.9.7 2.8a2 2 0 0 1-.5 2.1L8.1 9.9a16 16 0 0 0 6 6l1.3-1.3a2 2 0 0 1 2.1-.4c.9.3 1.8.6 2.8.7a2 2 0 0 1 1.7 2z',
  pin:'M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0zM12 10a2.5 2.5 0 1 0 0-5 2.5 2.5 0 0 0 0 5z',
  tow:'M3 17V9h8l3 3h5l2 3v2M6.5 20a1.8 1.8 0 1 0 0-3.6 1.8 1.8 0 0 0 0 3.6zM17 20a1.8 1.8 0 1 0 0-3.6 1.8 1.8 0 0 0 0 3.6zM11 9V6h3l2 3',
  plus:'M12 5v14M5 12h14',
  bolt:'M13 2L3 14h7l-1 8 10-12h-7z',
  star:'M12 3l2.7 5.5 6 .9-4.3 4.2 1 6-5.4-2.8-5.4 2.8 1-6L3.3 9.4l6-.9z',
  book:'M4 5a2 2 0 0 1 2-2h13v16H6a2 2 0 0 0-2 2zM4 5v14M8 7h7M8 11h5',
  wrench:'M14.7 6.3a4 4 0 0 0-5.4 5.2L4 16.8l3.2 3.2 5.3-5.3a4 4 0 0 0 5.2-5.4l-2.6 2.6-2.6-2.6z',
  home:'M3 11l9-8 9 8M5 10v10h5v-6h4v6h5V10',
};
const svg = (k,s=24)=>`<svg viewBox="0 0 24 24" width="${s}" height="${s}" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="${ICONS[k]||''}"/></svg>`;

const fmt = {
  money:n=>'$'+Number(n).toLocaleString('en-US',{minimumFractionDigits:(n%1?2:0),maximumFractionDigits:2}),
  date:d=>new Date(d).toLocaleDateString('en-US',{month:'short',day:'numeric',year:'numeric'}),
  time:d=>new Date(d).toLocaleTimeString('en-US',{hour:'2-digit',minute:'2-digit',hour12:true}),
  ago:d=>{const s=(Date.now()-new Date(d))/1000;if(s<3600)return Math.max(1,Math.round(s/60))+'m ago';if(s<86400)return Math.round(s/3600)+'h ago';return Math.round(s/86400)+'d ago';},
};

function toast(msg,kind='info'){
  let t=$('#toast'); if(!t){t=el('div','toast');t.id='toast';document.body.appendChild(t);}
  t.innerHTML=`<span class="dot ${kind==='auto'?'amber pulse':kind}"></span> ${msg}`;
  t.classList.add('show');clearTimeout(t._h);t._h=setTimeout(()=>t.classList.remove('show'),3000);
}

/* modal host */
function openModal(html,cls=''){
  let m=$('#modal'); if(!m){m=el('div','modal');m.id='modal';document.body.appendChild(m);}
  m.className='modal open '+cls;
  m.innerHTML=`<div class="modal__scrim" data-close></div><div class="modal__box">${html}</div>`;
  document.body.style.overflow='hidden';
  m.querySelectorAll('[data-close]').forEach(b=>b.addEventListener('click',closeModal));
  m.addEventListener('click',e=>{if(e.target.classList.contains('modal__scrim'))closeModal();});
  return m;
}
function closeModal(){const m=$('#modal');if(m){m.classList.remove('open');document.body.style.overflow='';m.innerHTML='';}}
addEventListener('keydown',e=>{if(e.key==='Escape')closeModal();});

/* Automation console — live feed proving Base44 wiring */
function initAutoConsole(){
  const btn=el('button','autoconsole-btn','⚡ <span>Automation feed</span> <b id="acCount">0</b>');
  btn.id='acBtn'; btn.setAttribute('aria-label','Open the live automation feed');
  const host=document.getElementById('acSlot');
  (host||document.body).appendChild(btn);
  const panel=el('div','autoconsole','<div class="autoconsole__head">⚡ AUTOMATION FEED <span class="tag">Base44 triggers</span><button id="acClose">✕</button></div><div class="autoconsole__body" id="acBody"><p class="autoconsole__empty">Interact with the app — booking, tow, status changes fire automations here.</p></div>');
  panel.id='autoPanel'; document.body.appendChild(panel);
  let count=0;
  btn.addEventListener('click',()=>panel.classList.toggle('open'));
  $('#acClose').addEventListener('click',()=>panel.classList.remove('open'));
  addEventListener('automation',e=>{
    count++; $('#acCount').textContent=count;
    const body=$('#acBody'); const empty=$('.autoconsole__empty'); if(empty)empty.remove();
    const item=el('div','autoconsole__item',`<div class="ac-name"><span class="dot amber"></span>${e.detail.name}</div><div class="ac-detail mono">${Object.entries(e.detail.detail).map(([k,v])=>`${k}: <b>${v}</b>`).join(' · ')}</div><div class="ac-time mono">${fmt.time(e.detail.at)}</div>`);
    body.prepend(item);
    toast('⚡ '+e.detail.name.split(' · ')[0]+' fired','auto');
    btn.classList.add('flash');setTimeout(()=>btn.classList.remove('flash'),600);
  });
}
