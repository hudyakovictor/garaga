/* ============================================================
   ROUTER — hash routes + contextual shell (public / portal / crm)
   ============================================================ */
const Router = (() => {
  const routes = {};
  const def = (path, area, render) => routes[path] = { area, render };

  // registered by page modules via window.Pages
  function register(){
    const P = window.Pages;
    def('/', 'public', P.home);
    def('/services','public', P.services);
    def('/service','public', P.serviceDetail);
    def('/about','public', P.about);
    def('/contact','public', P.contact);
    def('/specials','public', P.specials);
    def('/financing','public', P.financing);
    def('/book','public', P.book);
    def('/uikit','public', P.uikit);
    def('/portal','portal', P.portalHome);
    def('/portal/order','portal', P.portalOrder);
    def('/portal/garage','portal', P.portalGarage);
    def('/portal/history','portal', P.portalHistory);
    def('/portal/chat','portal', P.portalChat);
    def('/crm','crm', P.crmDash);
    def('/crm/orders','crm', P.crmOrders);
    def('/crm/order','crm', P.crmOrderDetail);
    def('/crm/tasks','crm', P.crmTasks);
    def('/crm/calendar','crm', P.crmCalendar);
    def('/crm/dispatch','crm', P.crmDispatch);
    def('/crm/reports','crm', P.crmReports);
    def('/crm/customers','crm', P.crmCustomers);
  }

  const SIDES = {
    portal:{ title:'CLIENT PORTAL', groups:[
      {label:'My Account', items:[
        ['/portal','home','Overview'],
        ['/portal/order','order','My Service Order'],
        ['/portal/garage','car','My Garage'],
        ['/portal/history','history','Service History'],
        ['/portal/chat','chat','Live Chat'],
      ]},
    ]},
    crm:{ title:'OWNER CRM', groups:[
      {label:'Shop', items:[
        ['/crm','dash','Dashboard'],
        ['/crm/orders','order','Orders'],
        ['/crm/tasks','tasks','Tasks'],
        ['/crm/calendar','calendar','Calendar'],
      ]},
      {label:'Operations', items:[
        ['/crm/dispatch','tow','Tow Dispatch'],
        ['/crm/reports','reports','Reports'],
        ['/crm/customers','users','Customers'],
        ['/crm','settings','Settings'],
      ]},
    ]},
  };

  // internal hash (works even if the sandboxed iframe won't honor location.hash)
  let _hash = (location.hash || '#/');
  function parse(){
    const h = _hash.replace(/^#/,'') || '/';
    const clean = ('/'+h.replace(/^\//,'')).split('?')[0].replace(/\/$/,'') || '/';
    const params = Object.fromEntries(new URLSearchParams(h.split('?')[1]||''));
    return { path:clean, params };
  }
  function navigate(hash){
    hash = hash.startsWith('#') ? hash : '#'+hash;
    _hash = hash;
    try{ history.replaceState(null,'',hash); }catch(e){ try{ location.hash = hash; }catch(_){} }
    render();
  }

  function sideFor(area, path){
    const cfg = SIDES[area]; if(!cfg) return '';
    const unread = (window.Store && Store.db.messages) ? Store.db.messages.filter(m=>m.unread).length : 0;
    const g = cfg.groups.map(gr=>`<div class="side__group">${gr.label}</div>`+gr.items.map(([p,icn,label])=>
      `<a href="#${p}" class="${p===path?'active':''}">${svg(icn,18)} <span>${label}</span>${label==='Live Chat'&&unread?`<span class="cnt" style="background:var(--amber);color:var(--amber-ink);border-radius:9px;padding:1px 6px">${unread}</span>`:''}</a>`).join('')).join('');
    return `<aside class="side"><div class="side__group">${cfg.title}</div>${g}
      <div class="side__spacer"></div>
      <div class="side__foot">Prototype · data mirrors Base44 entities</div></aside>`;
  }

  function render(){
    const np=$('#navprog'); if(np){np.classList.remove('go');void np.offsetWidth;np.classList.add('go');}
    const { path, params } = parse();
    // longest-prefix match
    let key = routes[path] ? path : Object.keys(routes).filter(r=>path.startsWith(r)).sort((a,b)=>b.length-a.length)[0];
    const route = routes[key] || routes['/'];
    const area = route.area;
    document.body.dataset.area = area;
    setActiveNav(path);

    const view = $('#view');
    if(area==='public'){
      view.innerHTML = `<div class="page">${route.render(params)}</div>`;
    } else {
      view.innerHTML = `<div class="app-shell">${sideFor(area,path)}<main class="content"><div class="page">${route.render(params)}</div></main></div>`;
    }
    if(route.mounted) route.mounted(params);
    window.scrollTo(0,0);
    if(window.Pages._after) window.Pages._after(path,params);
  }

  function setActiveNav(path){
    $$('.appbar__nav a').forEach(a=>{
      const t=a.getAttribute('href').replace('#','');
      const on = t===path || (t!=='/'&&path.startsWith(t));
      a.classList.toggle('active', on);
      if(on) a.setAttribute('aria-current','page'); else a.removeAttribute('aria-current');
    });
    document.title = 'Newcomb\'s Auto — '+(path==='/'?'Home':path.split('/').filter(Boolean).map(s=>s[0].toUpperCase()+s.slice(1)).join(' · ').split('?')[0]);
  }

  return { register, render, parse, navigate };
})();

// keep _hash in sync if the browser DOES fire hashchange (direct file/browser use)
window.addEventListener('hashchange', ()=>Router.navigate(location.hash||'#/'));

// GLOBAL click delegate: intercept every in-app "#/..." link and route
// directly — so navigation works even where the iframe won't fire hashchange.
document.addEventListener('click', (e)=>{
  const a = e.target.closest('a[href^="#/"], a[href="#"]');
  if(!a) return;
  const href = a.getAttribute('href');
  if(href && href.length>1){ e.preventDefault(); Router.navigate(href); }
});
