/* ============================================================
   BOOT — assemble appbar, wire global controls, start router
   ============================================================ */
// tiny global format helpers used inside template strings
window.fmtMoney = fmt.money; window.fmtDate = fmt.date; window.fmtTime = fmt.time;
window.telFmt = p => { const d=(''+p).replace(/\D/g,''); return d.length===10 ? `(${d.slice(0,3)}) ${d.slice(3,6)}-${d.slice(6)}` : p; };

// tow-truck icon: cab + flatbed carrying a simple car + small crane arm
function towIcon(s=18){return `<svg viewBox="0 0 28 20" width="${s*1.4}" height="${s}" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">
<path d="M1 15V8h4l2 3h4v4"/><path d="M5 8V5h2l2 3"/>
<path d="M11 15V11h11l4 2v2"/>
<path d="M14.5 11l1.3-2.2a1 1 0 0 1 .9-.5h3.1a1 1 0 0 1 .8.4L23 11"/>
<path d="M22 4l4 1.5M22 4v4" stroke-width="1.4"/>
<circle cx="6.5" cy="16" r="1.6"/><circle cx="20" cy="16" r="1.6"/>
<path d="M1 15h3.5M8 15h2.5M13 15h5.5M22 15h4"/></svg>`;}
// phone handset icon
function phoneIcon(s=17){return `<svg viewBox="0 0 24 24" width="${s}" height="${s}" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M5 3h3.5l1.5 5-2 1.5a12 12 0 0 0 6 6l1.5-2 5 1.5V21a1 1 0 0 1-1 1A18 18 0 0 1 4 4a1 1 0 0 1 1-1z"/></svg>`;}
function buildAppbar(){
  const nav = [['/','Home'],['/services','Services'],['/about','About'],['/specials','Specials'],['/financing','Financing'],['/contact','Contact'],['/uikit','UI Kit']];
  const bar = el('header','appbar');
  bar.innerHTML = `
    <div class="appbar__brand">
      <button class="burger" id="burger" aria-label="Menu"><span></span><span></span><span></span></button>
      <a href="#/" class="brandmark" aria-label="Newcomb's Auto Repair">
        <span class="brandmark__em">${towIcon(20)}</span>
        <span class="brandmark__tx"><b>NEWCOMB'S</b><i>AUTO REPAIR</i></span>
      </a>
    </div>
    <nav class="appbar__nav">${nav.map(n=>`<a href="#${n[0]}">${n[1]}</a>`).join('')}</nav>
    <div class="appbar__right">
      <div class="roleswitch" role="tablist" aria-label="View as">
        <button data-role="public" class="active">Public</button>
        <button data-role="portal">Client</button>
        <button data-role="crm">Owner</button>
      </div>
      <a href="tel:${window.SEED.shop.phone}" class="appbar__phone" aria-label="Call ${window.telFmt(window.SEED.shop.phone)}" title="${window.telFmt(window.SEED.shop.phone)}">${phoneIcon()}</a>
      <button class="tow" id="towBtn" aria-label="Call a tow truck"><span class="tow__ic">${towIcon()}</span><span class="tow__tx">Tow Truck</span></button>
    </div>`;
  document.body.prepend(bar);
  const prog=el('div','navprog'); prog.id='navprog'; document.body.prepend(prog);
  // chrome gradient defs for service icons
  const defs=el('div'); defs.innerHTML=`<svg width="0" height="0" style="position:absolute" aria-hidden="true"><defs><linearGradient id="chrome" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#f3f6fa"/><stop offset="0.4" stop-color="#aab4bf"/><stop offset="0.55" stop-color="#79858f"/><stop offset="1" stop-color="#e6ebf1"/></linearGradient></defs></svg>`; document.body.prepend(defs.firstChild);

  $('#towBtn').addEventListener('click', ()=>window.Flows.tow());
  // global booking trigger: any [data-book] element opens the flow (optional service id)
  document.addEventListener('click', e=>{ const b=e.target.closest('[data-book]'); if(b){ e.preventDefault(); window.Flows.booking(b.dataset.book||''); } });
  // mobile public nav overlay
  const mnav = el('div','mnav','');
  mnav.id='mnav';
  mnav.innerHTML = `<div class="mnav__panel">${nav.map(n=>`<a href="#${n[0]}">${n[1]}</a>`).join('')}<a href="#/portal">Client Portal</a><a href="#/crm">Owner CRM</a><button class="btn btn--amber btn--block" data-book style="margin-top:12px">Book a bay</button></div>`;
  document.body.appendChild(mnav);
  mnav.addEventListener('click',e=>{ if(e.target===mnav||e.target.closest('a')) document.body.classList.remove('mnav-open'); });

  $('#burger').addEventListener('click', ()=>{
    const area = document.body.dataset.area;
    if (area === 'public') document.body.classList.toggle('mnav-open');
    else document.body.classList.toggle('side-open');
  });
  $$('.roleswitch button').forEach(b=>b.addEventListener('click',()=>{
    $$('.roleswitch button').forEach(x=>x.classList.remove('active')); b.classList.add('active');
    const r=b.dataset.role; Router.navigate(r==='public'?'#/':r==='portal'?'#/portal':'#/crm');
  }));
  // reflect area on role switch when navigating
  window.addEventListener('hashchange',()=>{
    const area=document.body.dataset.area;
    $$('.roleswitch button').forEach(x=>x.classList.toggle('active',x.dataset.role===area));
    document.body.classList.remove('side-open');
    document.body.classList.remove('mnav-open');
  });
}

function buildFooter(){
  const s=window.SEED.shop;
  const f=el('footer','footer');
  f.innerHTML=`
    <div class="footer__grid">
      <div class="footer__brand">
        <span class="brandmark" style="margin-bottom:14px"><span class="brandmark__em">${towIcon(20)}</span><span class="brandmark__tx"><b>NEWCOMB'S</b><i>AUTO REPAIR</i></span></span>
        <p class="mono faint">${s.addr}</p>
        <p class="mono faint">${s.hours}</p>
      </div>
      <div class="footer__col"><h4>Services</h4>
        <a href="#/services">All services</a><a href="#/service?id=brakes">Brakes</a><a href="#/service?id=body">Body &amp; Paint</a><a href="#/service?id=diagnostics">Diagnostics</a></div>
      <div class="footer__col"><h4>Shop</h4>
        <a href="#/about">About</a><a href="#/specials">Specials</a><a href="#/financing">Financing</a><a href="#/contact">Contact</a></div>
      <div class="footer__col"><h4>Account</h4>
        <a href="#/portal">Client Portal</a><a href="#/crm">Owner CRM</a><a href="#/book">Book a bay</a><a href="#" onclick="Flows.tow();return false">Request a tow</a></div>
      <div class="footer__col"><h4>Contact</h4>
        <a href="tel:${s.phone}">${window.telFmt(s.phone)}</a><a href="mailto:${s.email}">${s.email}</a>
        <div class="footer__badges"><span class="badge ghost">ASE</span><span class="badge ghost">NAPA</span><span class="badge ghost">2-YR</span></div></div>
    </div>
    <div class="footer__bar">
      <span class="mono faint">© ${new Date().getFullYear()} Newcomb's Auto Repair, LLC · Family owned</span>
      <span id="acSlot"></span>
    </div>`;
  document.body.appendChild(f);
}

document.addEventListener('DOMContentLoaded', ()=>{
  buildAppbar();
  Router.register();
  Router.render();
  buildFooter();
  initAutoConsole();
  if(window.Agent) Agent.mount();
});
