/* ============================================================
   AI SUPERAGENT (A10) — floating assistant.
   Prototype uses a rules/intent engine over the shop knowledge base.
   On Base44 this becomes a real AI Superagent trained on Services + FAQ +
   hours, able to create Booking / TowRequest records and hand off to staff.
   ============================================================ */
window.Agent = (() => {
  const S = () => window.Store.db;
  let open=false, greeted=false;

  // knowledge base drawn from the same entities Base44 will use
  function kb(){
    const s=S().shop;
    return {
      hours:s.hours, phone:window.telFmt(s.phone), addr:s.addr,
      warranty:'All NAPA parts carry a 2-year / 24,000-mile warranty.',
      services:S().services.map(x=>`${x.name} (${window.fmtMoney(x.price_min)}–${window.fmtMoney(x.price_max)})`).join(', '),
      inspection:'Virginia state inspection is $20 and takes about 30 minutes.',
      tow:'Yes — we offer 24/7 tow service. I can dispatch a truck to your GPS location right now.',
      financing:'Yes — we offer financing through Snap, Synchrony and Acima. Quick approval, low monthly payments.',
    };
  }

  // intent matcher → reply (+ optional action)
  function respond(text){
    const t=text.toLowerCase(); const k=kb();
    const has=(...w)=>w.some(x=>t.includes(x));
    if(has('tow','stuck','breakdown','broke down','won\'t start','wont start','stranded'))
      return {msg:k.tow, action:{label:'🚨 Call a tow truck',run:()=>window.Flows.tow()}};
    if(has('book','appointment','schedule','reserve','bay','slot'))
      return {msg:"I can book that for you. Which service do you need?", action:{label:'Open booking',run:()=>window.Flows.booking()}};
    if(has('hour','open','close','when'))
      return {msg:`We're open ${k.hours}. Night drop is available 24/7.`};
    if(has('where','address','location','directions'))
      return {msg:`We're at ${k.addr}.`, action:{label:'Open map',run:()=>window.open('https://maps.google.com/?q='+encodeURIComponent(k.addr),'_blank')}};
    if(has('warranty','guarantee'))
      return {msg:k.warranty};
    if(has('inspection','state inspect','sticker'))
      return {msg:k.inspection, action:{label:'Book inspection',run:()=>window.Flows.booking('diagnostics')}};
    if(has('financ','payment plan','pay over','afford'))
      return {msg:k.financing, action:{label:'Financing calculator',run:()=>Router.navigate('#/financing')}};
    // service-specific intents win before the generic price catch-all
    if(has('brake'))return {msg:'Brake service runs $350–550 (pads, rotors, fluid) with a free safety analysis and 2-year warranty.',action:{label:'Book brakes',run:()=>window.Flows.booking('brakes')}};
    if(has('oil'))return {msg:'A synthetic-blend oil change is $55–95 and takes about 30 minutes — includes a fluid top-off and multi-point check.',action:{label:'Book oil change',run:()=>window.Flows.booking('oil')}};
    if(has('paint','dent','body','collision','scratch'))return {msg:"Big Jay's shop handles body & paint, collision and dent work — and we bill the insurance direct.",action:{label:'Start an estimate',run:()=>window.Flows.booking('body')}};
    if(has('tire','wheel'))return {msg:'We sell & mount tires — most in stock within an hour. Mount is $10, plugs $5, computer balancing included.',action:{label:'Book tires',run:()=>window.Flows.booking('tires')}};
    if(has('price','cost','how much','estimate','quote'))
      return {msg:`Here's our pricing range: ${k.services}. Want an exact estimate? I can book a diagnostic.`, action:{label:'Book diagnostic',run:()=>window.Flows.booking('diagnostics')}};
    if(has('human','person','staff','advisor','talk to','call'))
      return {msg:`Sure — call us at ${k.phone} or I can flag an advisor to reach out.`, action:{label:'Request a callback',run:()=>{window.Store.createLead('Contact',{via:'AI agent',note:'callback requested'});Agent.say('bot','Done — an advisor will call you shortly.');}}};
    if(has('hi','hello','hey','yo'))return {msg:"Hey! I'm the Newcomb's assistant. Ask me about services, hours, pricing — or say \"tow\" if you're stuck."};
    if(has('thanks','thank you','thx'))return {msg:"Anytime! Anything else I can help with?"};
    return {msg:"I can help with booking, tow dispatch, pricing, hours, warranty and directions. What do you need?", action:{label:'Book a service',run:()=>window.Flows.booking()}};
  }

  const quick=['Book a service','Are you open now?','How much for brakes?',"I'm stuck — tow?"];

  function mount(){
    const btn=el('button','agent-fab','');
    btn.id='agentFab'; btn.setAttribute('aria-label','Ask the assistant');
    btn.innerHTML=`${svg('chat',19)}<span class="agent-fab__lbl">Ask AI</span><span class="agent-fab__dot"></span>`;
    document.body.appendChild(btn);
    const win=el('div','agent-win');
    win.id='agentWin';
    win.innerHTML=`
      <div class="agent-head"><span class="agent-av">AI</span><div><b>Newcomb's Assistant</b><span class="mono faint">Superagent · online</span></div><button id="agentClose" aria-label="Close">${svg('plus',16).replace('M12 5v14M5 12h14','M6 6l12 12M18 6L6 18')}</button></div>
      <div class="agent-msgs" id="agentMsgs"></div>
      <div class="agent-quick" id="agentQuick">${quick.map(q=>`<button class="agent-chip" data-q="${q}">${q}</button>`).join('')}</div>
      <form class="agent-input" id="agentForm"><input id="agentIn" placeholder="Ask anything…" autocomplete="off"><button class="agent-send" type="submit">${svg('arrow',18)}</button></form>`;
    document.body.appendChild(win);

    btn.addEventListener('click',()=>toggle(true));
    $('#agentClose').addEventListener('click',()=>toggle(false));
    $('#agentForm').addEventListener('submit',e=>{e.preventDefault();const i=$('#agentIn');if(!i.value.trim())return;const q=i.value;i.value='';ask(q);});
    $('#agentQuick').addEventListener('click',e=>{const b=e.target.closest('[data-q]');if(b)ask(b.dataset.q);});
  }
  function toggle(v){open=v;$('#agentWin').classList.toggle('open',v);$('#agentFab').classList.toggle('hide',v);
    if(v&&!greeted){greeted=true;say('bot',"Hey! I'm the Newcomb's assistant 🔧 Ask me about services, hours or pricing — or tap a shortcut below.");}}
  function ask(text){
    say('me',text);
    const typing=say('bot','<span class="agent-typing"><i></i><i></i><i></i></span>',true);
    setTimeout(()=>{
      const r=respond(text); typing.remove();
      say('bot',r.msg);
      if(r.action){const b=el('button','agent-action',r.action.label);b.onclick=()=>{r.action.run();};$('#agentMsgs').appendChild(b);scroll();
        window.Store && window.dispatchEvent(new CustomEvent('automation',{detail:{name:'A10 · AI Superagent handled query',detail:{intent:text.slice(0,40)},at:new Date().toISOString()}}));}
      scroll();
    },700);
  }
  function say(who,html,raw){const wrap=el('div','agent-msg '+who,raw?html:esc(html));if(raw)wrap.innerHTML=html; $('#agentMsgs').appendChild(wrap);scroll();return wrap;}
  function esc(s){return s.replace(/&/g,'&amp;').replace(/</g,'&lt;');}
  function scroll(){const m=$('#agentMsgs');if(m)m.scrollTop=m.scrollHeight;}

  return { mount, say:(who,t)=>say(who,t), respond };
})();
