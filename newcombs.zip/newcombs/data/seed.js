/* ============================================================
   SEED DATA — mirrors Base44 entities 1:1 (see docs/01-BASE44-ENTITIES.md)
   In-memory only; the real app reads these from Base44.
   ============================================================ */
window.SEED = {
  shop:{ name:"Newcomb's Auto Repair", phone:'5405160196', addr:'123 Main Street, Drakes Branch, VA 23937', email:'info@newcombsauto.com',
    hours:'Mon–Fri 8–6 · Sat 8–Noon · Sun Closed' },

  services:[
    {key:'diagnostics',name:'Diagnostics',category:'Diagnostics',price_min:20,price_max:50,duration:'40 min',status_tag:'attention'},
    {key:'engine',name:'Engine Repair',category:'Engine',price_min:180,price_max:2400,duration:'1–3 days',status_tag:'attention'},
    {key:'brakes',name:'Brake Service',category:'Brakes',price_min:350,price_max:550,duration:'2–3 h',status_tag:'priority'},
    {key:'suspension',name:'Suspension',category:'Tires & Suspension',price_min:150,price_max:600,duration:'2–4 h',status_tag:'attention'},
    {key:'oil',name:'Oil & Fluids',category:'Maintenance',price_min:55,price_max:95,duration:'30 min',status_tag:'ok'},
    {key:'tires',name:'Tires',category:'Tires & Suspension',price_min:100,price_max:900,duration:'45 min',status_tag:'attention'},
    {key:'dent',name:'Dent Repair',category:'Body & Paint',price_min:250,price_max:750,duration:'1–2 days',status_tag:'attention'},
    {key:'paint',name:'Paint Correction',category:'Body & Paint',price_min:199,price_max:1200,duration:'1–3 days',status_tag:'attention'},
    {key:'glass',name:'Glass & Windshield',category:'Glass',price_min:75,price_max:350,duration:'45 min',status_tag:'ok'},
    {key:'detailing',name:'Detailing',category:'Detailing',price_min:129,price_max:299,duration:'2–4 h',status_tag:'ok'},
    {key:'body',name:'Body Repair',category:'Body & Paint',price_min:500,price_max:6000,duration:'multi-day',status_tag:'priority'},
  ],

  technicians:[
    {id:'t1',name:'Mike Johnson',role:'Service Advisor',active:true,avatar:'av-4'},
    {id:'t2',name:'Tom Davis',role:'Mechanic',active:true,avatar:'av-3'},
    {id:'t3',name:'Sarah Williams',role:'Body',active:true,avatar:'av-5'},
    {id:'t4',name:'J.J. Newcomb',role:'Welder',active:true,avatar:'av-1'},
    {id:'t5',name:'Big Jay',role:'Paint',active:true,avatar:'av-4'},
  ],

  customers:[
    {id:'c1',name:'John Smith',phone:'540-555-0110',email:'john@example.com',avatar:'av-1'},
    {id:'c2',name:'Sarah Johnson',phone:'540-555-0112',email:'sarahj@example.com',avatar:'av-2'},
    {id:'c3',name:'Mike Brown',phone:'540-555-0114',email:'mikeb@example.com',avatar:'av-3'},
    {id:'c4',name:'David Wilson',phone:'540-555-0116',email:'davidw@example.com',avatar:'av-4'},
    {id:'c5',name:'Lisa Anderson',phone:'540-555-0118',email:'lisaa@example.com',avatar:'av-5'},
  ],

  vehicles:[
    {id:'v1',customer:'c1',year:2020,make:'Ford',model:'F-150 XLT',plate:'VAA-1234',vin:'1FTFW1E4XLKD12345',color:'Magnetic Gray',mileage:45672,active:true},
    {id:'v2',customer:'c1',year:2018,make:'Chevrolet',model:'Silverado 1500',plate:'VAB-9678',vin:'3GCUKREC0JG123456',color:'Black',mileage:61230},
    {id:'v3',customer:'c1',year:2016,make:'Jeep',model:'Grand Cherokee',plate:'VAC-9012',vin:'1C4RJFBG0GC123456',color:'White',mileage:88400},
    {id:'v4',customer:'c2',year:2018,make:'Chevy',model:'Silverado',plate:'VAD-2201',color:'Silver',mileage:52110},
    {id:'v5',customer:'c3',year:2021,make:'Ram',model:'1500',plate:'VAE-3302',color:'Blue',mileage:33900},
  ],

  // status: Pending, Inspection, In Progress, Quality Check, Ready, Completed
  orders:[
    {number:'NCAR-2024-0587',customer:'c1',vehicle:'v1',service:'dent',technician:'t1',status:'In Progress',stage:3,progress:60,
      estimate_labor:199,estimate_parts:0,estimate_total:210.94,scheduled_at:'2024-05-12T09:15',created_date:'2024-05-12'},
    {number:'NCAR-2024-0586',customer:'c2',vehicle:'v4',service:'brakes',technician:'t2',status:'Inspection',stage:2,progress:30,
      estimate_labor:180,estimate_parts:140,estimate_total:341,scheduled_at:'2024-05-13T10:00',created_date:'2024-05-13'},
    {number:'NCAR-2024-0585',customer:'c3',vehicle:'v5',service:'oil',technician:'t2',status:'Completed',stage:5,progress:100,
      estimate_labor:40,estimate_parts:49,estimate_total:88,scheduled_at:'2024-05-11T14:00',created_date:'2024-05-11'},
    {number:'NCAR-2024-0584',customer:'c4',vehicle:'v4',service:'tires',technician:'t3',status:'Completed',stage:5,progress:100,
      estimate_labor:20,estimate_parts:520,estimate_total:540,scheduled_at:'2024-05-10T11:00',created_date:'2024-05-10'},
    {number:'NCAR-2024-0583',customer:'c5',vehicle:'v5',service:'diagnostics',technician:'t1',status:'Pending',stage:1,progress:5,
      estimate_labor:60,estimate_parts:0,estimate_total:60,scheduled_at:'2024-05-14T09:00',created_date:'2024-05-14'},
    {number:'NCAR-2024-0582',customer:'c2',vehicle:'v2',service:'engine',technician:'t4',status:'In Progress',stage:3,progress:45,
      estimate_labor:600,estimate_parts:900,estimate_total:1500,scheduled_at:'2024-05-13T08:00',created_date:'2024-05-13'},
  ],

  orderUpdates:[
    {order:'NCAR-2024-0587',message:'Vehicle inspection completed. Dent confirmed on driver side door.',photos:['svc-dent'],created_date:'2024-05-12T10:30'},
    {order:'NCAR-2024-0587',message:'Dent removal in progress. Making great progress.',photos:['svc-dent-after'],created_date:'2024-05-13T08:45'},
  ],

  messages:[
    {order:'NCAR-2024-0587',sender:'staff',sender_name:'Mike Johnson',body:'Hi there! I wanted to update you on your truck.',created_date:'2024-05-13T08:41'},
    {order:'NCAR-2024-0587',sender:'customer',sender_name:'John Smith',body:'Hi Mike, thanks for the update!',created_date:'2024-05-13T08:44'},
    {order:'NCAR-2024-0587',sender:'staff',sender_name:'Mike Johnson',body:'The dent removal is almost complete. Should be ready for quality check tomorrow morning.',created_date:'2024-05-13T08:47'},
    {order:'NCAR-2024-0587',sender:'staff',sender_name:'Mike Johnson',body:'Here\'s a shot from the bay 👇',photo:'svc-dent-after',created_date:'2024-05-13T08:48'},
    {order:'NCAR-2024-0582',sender:'staff',sender_name:'J.J. Newcomb',body:'Engine\'s on the stand — timing components look worn, sending an estimate shortly.',created_date:'2024-05-13T10:10',unread:true},
  ],

  serviceHistory:[
    {date:'2024-05-12',service:'Dent Repair',mileage:45672,total:210.94,status:'In Progress'},
    {date:'2024-04-02',service:'Oil Change & Filter',mileage:44890,total:88.99,status:'Completed'},
    {date:'2024-01-15',service:'Brake Service',mileage:43210,total:320.50,status:'Completed'},
    {date:'2023-11-08',service:'Tire Rotation',mileage:41690,total:49.99,status:'Completed'},
    {date:'2023-09-21',service:'Diagnostics',mileage:40567,total:129.99,status:'Completed'},
    {date:'2023-07-10',service:'A/C Service',mileage:38765,total:199.99,status:'Completed'},
  ],

  tasks:[
    {id:'k1',order:'NCAR-2024-0583',title:'Diagnostics — 2016 Jeep',assignee:'t1',column:'Pending',due:'2024-05-14'},
    {id:'k2',order:'NCAR-2024-0585',title:'AC Service — 2020 Honda',assignee:'t2',column:'Pending',due:'2024-05-13'},
    {id:'k3',order:'NCAR-2024-0587',title:'Dent Repair — 2020 F-150',assignee:'t3',column:'In Progress',due:'2024-05-14'},
    {id:'k4',order:'NCAR-2024-0586',title:'Brake Service — Silverado',assignee:'t2',column:'In Progress',due:'2024-05-15'},
    {id:'k5',order:'NCAR-2024-0582',title:'Transmission — Ford Escape',assignee:'t4',column:'In Progress',due:'2024-05-15'},
    {id:'k6',order:'NCAR-2024-0584',title:'Tire Rotation — Toyota',assignee:'t3',column:'Completed',due:'2024-05-14'},
    {id:'k7',order:'NCAR-2024-0585',title:'Oil Change — Ram 1500',assignee:'t2',column:'Completed',due:'2024-05-11'},
  ],

  reviews:[
    {name:'Jason M.',rating:5,text:'Great service and honest pricing. They fixed my truck right the first time.'},
    {name:'Rachel T.',rating:5,text:'Professional, fast, and friendly. Highly recommend!'},
    {name:'Mike D.',rating:5,text:'Best auto repair shop in Drakes Branch. Period.'},
    {name:'Karen P.',rating:4,text:'Fair prices and they explain everything. Will be back.'},
  ],

  specials:[
    {title:'$25 OFF',sub:'Brake Service',note:'Plus free brake inspection',exp:'06/30/2024'},
    {title:'$50 OFF',sub:'Suspension Work',note:'On any suspension repair',exp:'06/30/2024'},
    {title:'10% OFF',sub:'Military Discount',note:'For all active & veteran',exp:'Ongoing'},
  ],

  faqs:[
    ['What are your shop hours?','Mon–Fri 8:00 AM–6:00 PM, Sat 8:00 AM–Noon, Sunday closed. Night drop available 24/7.'],
    ['Do you offer a warranty?','Yes — all NAPA parts carry a 2-year / 24,000-mile warranty.'],
    ['Do I need an appointment?','Walk-ins welcome, but booking a bay guarantees your slot and a faster turnaround.'],
    ['Do you work on all makes and models?','Yes, foreign and domestic — cars, trucks, and fleet vehicles.'],
    ['Do you offer tow service?','Yes. Use the "Call Tow Truck" button — it shares your GPS so we come straight to you.'],
    ['How can I get an estimate?','Book online, call us, or start a body-repair estimate from the Body Repair page.'],
  ],

  gallery:['svc-engine','svc-brakes','svc-suspension','svc-body','svc-paint','svc-diagnostics'],

  tows:[
    {id:'tw1',ref:'TOW-8K2P1',lat:37.06120,lng:-78.60340,accuracy:12,vehicle_type:'Truck',problem:"Won't start — clicking",status:'Dispatched',created_date:'2024-05-14T08:12',eta:14},
    {id:'tw2',ref:'TOW-4M9Q2',lat:37.04980,lng:-78.61870,accuracy:8,vehicle_type:'SUV',problem:'Flat tire on Rt 15',status:'Arrived',created_date:'2024-05-14T07:40',eta:0},
    {id:'tw3',ref:'TOW-7X3R8',lat:37.07210,lng:-78.59110,accuracy:25,vehicle_type:'Car',problem:'Accident — front damage',status:'Requested',created_date:'2024-05-14T08:30',eta:19},
  ],
};
